/**
 * @project My-Codex
 * @provenance:rogan-core
 * @author Rogan Kim (GeunHu Kim) & AI Architect
 * @license MIT
 * @description Native Tool Registry executing local commands, file manipulation, and diffs with sandbox checks.
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawn, exec } = require('node:child_process');
const { GoogleConnector } = require('../connectors/GoogleConnector.js');
const { NotionConnector } = require('../connectors/NotionConnector.js');
const { AsideBrowser } = require('../browser/AsideBrowser.js');
const { PasskeyVault } = require('../auth/PasskeyVault.js');
const { BrowserWorkspace } = require('../workspace/BrowserWorkspace.js');
const { SpaceKeeperConnector } = require('../connectors/SpaceKeeperConnector.js');
const STORAGE_GUARD = '/Users/rogan/bin/storage-guard';
const READ_ONLY_MUTATION_METHODS = new Set([
  'googleDriveCreate', 'googleDriveUpdate', 'gmailSend',
  'notionCreatePage', 'notionUpdatePage', 'notionAppendBlocks',
  'browserOpen', 'browserNavigate', 'browserAct', 'browserHistory', 'browserRecipe',
  'browserWorkspaceSnapshot', 'browserWorkspaceRestore', 'browserWorkspaceFocus', 'browserWorkspaceOpen',
  'vaultRequestCredential'
]);

function storageBudgetForCommand(command, explicitBudget) {
  if (explicitBudget !== undefined) {
    const value = Number(explicitBudget);
    if (!Number.isFinite(value) || value <= 0 || value > 10000) throw new Error('storagePeakGiB must be between 0 and 10000.');
    return value;
  }
  const value = String(command || '');
  if (/\b(xcodebuild|cargo\s+build|flutter\s+build|electron-builder|npm\s+(?:run\s+)?build|pnpm\s+(?:run\s+)?build|yarn\s+(?:run\s+)?build)\b/i.test(value)) return 8;
  if (/\b(npm\s+(?:ci|install)|pnpm\s+install|yarn\s+install|cargo\s+(?:fetch|check)|flutter\s+pub\s+get)\b/i.test(value)) return 4;
  if (/\b(zip|ditto|tar|7z|asar)\b|\b(curl|wget)\b[^\n]*(?:\s-o\s|\s-O\s|--output(?:=|\s))/i.test(value)) return 2;
  return null;
}

function shellInvocation(command, platform = process.platform, env = process.env) {
  return platform === 'win32'
    ? { executable: env.ComSpec || 'cmd.exe', args: ['/d', '/s', '/c', command] }
    : { executable: '/bin/zsh', args: ['-c', command] };
}

class ToolRegistry {
  constructor(options = {}) {
    this.workspaceDir = options.workspaceDir || process.cwd();
    this.sandboxRoot = options.sandboxRoot ? path.resolve(options.sandboxRoot) : null;
    this.commandRunner = options.commandRunner || null;
    this.providerConnectionsEnabled = options.providerConnectionsEnabled !== false;
    this.approvalPolicy = options.approvalPolicy || 'on-request'; // 'never', 'on-request', 'read-only'
    this.activeProcesses = new Map();

    // Google Workspace & Notion Connectors
    this.google = options.googleConnector || new GoogleConnector(options.connectorOptions || {});
    this.notion = options.notionConnector || new NotionConnector(options.connectorOptions || {});
    this.spaceKeeper = options.spaceKeeperConnector || new SpaceKeeperConnector(options.spaceKeeperOptions || {});

    // Desktop hosts may inject their own embedded browser; CLI keeps Aside.
    this.browser = options.browserEnabled === false ? null : (options.browser || new AsideBrowser());

    // Secure Passkey & Credential Vault
    this.vault = options.vault || new PasskeyVault(options.vaultOptions || {});

    // Sovereign Chrome & Firefox Browser Workspace
    this.browserWorkspace = options.browserWorkspace || new BrowserWorkspace(options.browserWorkspaceOptions || {});
  }

  setWorkspace(dir) {
    this.workspaceDir = path.resolve(dir);
  }

  _assertMutationAllowed(method) {
    if (this.approvalPolicy === 'read-only') throw new Error(`${method} is blocked under read-only policy.`);
  }

  resolvePath(relOrAbsPath) {
    const resolved = path.resolve(path.isAbsolute(relOrAbsPath) ? relOrAbsPath : path.resolve(this.workspaceDir, relOrAbsPath));
    if (this.sandboxRoot) {
      const relative = path.relative(this.sandboxRoot, resolved);
      if (relative === '..' || relative.startsWith(`..${path.sep}`) || path.isAbsolute(relative)) throw new Error('Path is outside the isolated profile.');
      let existing = resolved;
      while (!fs.existsSync(existing) && existing !== path.dirname(existing)) existing = path.dirname(existing);
      const realRelative = path.relative(this.sandboxRoot, fs.realpathSync(existing));
      if (realRelative === '..' || realRelative.startsWith(`..${path.sep}`) || path.isAbsolute(realRelative)) throw new Error('Path resolves outside the isolated profile.');
    }
    return resolved;
  }

  /**
   * Execute bash/zsh shell command with streaming output
   */
  async execCommand(command, onChunk = null, options = {}) {
    if (this.approvalPolicy === 'read-only') {
      throw new Error('Shell commands are blocked under read-only policy.');
    }
    if (this.sandboxRoot) {
      if (!this.commandRunner) throw new Error('Shell commands are disabled in isolated mode.');
      return this.commandRunner(command, onChunk, options);
    }
    const cwd = options.cwd ? this.resolvePath(options.cwd) : this.workspaceDir;
    const storagePeakGiB = process.platform === 'darwin'
      ? storageBudgetForCommand(command, options.storagePeakGiB)
      : null;
    const timeoutMs = options.timeoutMs || (storagePeakGiB ? 30 * 60 * 1000 : 120000);
    const task = String(options.storageTask || 'only-chat-command').replace(/[^A-Za-z0-9._-]/g, '-').slice(0, 128);

    return new Promise((resolve, reject) => {
      const shell = shellInvocation(command);
      const executable = storagePeakGiB ? STORAGE_GUARD : shell.executable;
      const args = storagePeakGiB
        ? ['run', '--task', task, '--peak-gib', String(storagePeakGiB), '--target', '/System/Volumes/Data', '--', shell.executable, ...shell.args]
        : shell.args;
      const child = spawn(executable, args, {
        cwd,
        env: { ...process.env, PATH: process.env.PATH },
        stdio: [options.input === undefined ? 'ignore' : 'pipe', 'pipe', 'pipe']
      });
      if (options.input !== undefined) child.stdin.end(options.input);

      const pid = child.pid;
      this.activeProcesses.set(pid, child);

      let stdout = '';
      let stderr = '';
      let killed = false;

      const timer = setTimeout(() => {
        killed = true;
        child.kill('SIGTERM');
      }, timeoutMs);

      child.stdout.on('data', chunk => {
        const text = chunk.toString();
        stdout += text;
        if (onChunk) onChunk({ type: 'stdout', text });
      });

      child.stderr.on('data', chunk => {
        const text = chunk.toString();
        stderr += text;
        if (onChunk) onChunk({ type: 'stderr', text });
      });

      child.on('close', code => {
        clearTimeout(timer);
        this.activeProcesses.delete(pid);
        resolve({
          exitCode: killed ? 124 : (code ?? 0),
          stdout,
          stderr,
          timedOut: killed,
          ...(storagePeakGiB ? { storageGuard: { task, peakGiB: storagePeakGiB } } : {})
        });
      });

      child.on('error', err => {
        clearTimeout(timer);
        this.activeProcesses.delete(pid);
        reject(err);
      });
    });
  }

  /**
   * Read file content
   */
  async readFile(filePath, startLine = 1, endLine = null) {
    const fullPath = this.resolvePath(filePath);
    if (!fs.existsSync(fullPath)) {
      throw new Error(`File not found: ${filePath}`);
    }
    const content = fs.readFileSync(fullPath, 'utf8');
    const lines = content.split('\n');
    
    if (startLine > 1 || endLine !== null) {
      const s = Math.max(1, startLine) - 1;
      const e = endLine !== null ? Math.min(lines.length, endLine) : lines.length;
      return lines.slice(s, e).join('\n');
    }
    return content;
  }

  /**
   * Write or overwrite file
   */
  async writeFile(filePath, content) {
    if (this.approvalPolicy === 'read-only') throw new Error('write_file is blocked under read-only policy.');
    const fullPath = this.resolvePath(filePath);
    const dir = path.dirname(fullPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(fullPath, content, 'utf8');
    return { path: fullPath, bytes: Buffer.byteLength(content) };
  }

  /**
   * Edit file via targeted replacement
   */
  async editFile(filePath, target, replacement) {
    if (this.approvalPolicy === 'read-only') throw new Error('edit_file is blocked under read-only policy.');
    const fullPath = this.resolvePath(filePath);
    if (!fs.existsSync(fullPath)) {
      throw new Error(`Cannot edit missing file: ${filePath}`);
    }
    const content = fs.readFileSync(fullPath, 'utf8');
    if (!content.includes(target)) {
      throw new Error(`Target string not found in ${filePath}`);
    }
    const updated = content.replaceAll(target, replacement);
    fs.writeFileSync(fullPath, updated, 'utf8');
    return { path: fullPath, modified: true };
  }

  /**
   * Apply patch / git diff
   */
  async applyPatch(patchString) {
    if (this.approvalPolicy === 'read-only') throw new Error('apply_patch is blocked under read-only policy.');
    return this.execCommand('git apply -', null, { input: patchString });
  }

  // =========================================================================
  // Google Workspace (Drive & Gmail Edit Tools)
  // =========================================================================

  async googleDriveList(options = {}) {
    if (!this.providerConnectionsEnabled) throw new Error('Google Drive is disabled in isolated mode.');
    return this.google.driveListFiles(options);
  }

  async googleDriveRead(fileId) {
    if (!this.providerConnectionsEnabled) throw new Error('Google Drive is disabled in isolated mode.');
    return this.google.driveReadFile(fileId);
  }

  async googleDriveCreate(name, mimeType, content, parentId) {
    this._assertMutationAllowed('google_drive_create');
    if (!this.providerConnectionsEnabled) throw new Error('Google Drive is disabled in isolated mode.');
    return this.google.driveCreateFile(name, mimeType, content, parentId);
  }

  async googleDriveUpdate(fileId, content, mimeType) {
    this._assertMutationAllowed('google_drive_update');
    if (!this.providerConnectionsEnabled) throw new Error('Google Drive is disabled in isolated mode.');
    return this.google.driveUpdateFile(fileId, content, mimeType);
  }

  async gmailList(options = {}) {
    if (!this.providerConnectionsEnabled) throw new Error('Gmail is disabled in isolated mode.');
    return this.google.gmailListMessages(options);
  }

  async gmailRead(messageId) {
    if (!this.providerConnectionsEnabled) throw new Error('Gmail is disabled in isolated mode.');
    return this.google.gmailReadMessage(messageId);
  }

  async gmailSend(to, subject, bodyText) {
    this._assertMutationAllowed('gmail_send');
    if (!this.providerConnectionsEnabled) throw new Error('Gmail is disabled in isolated mode.');
    return this.google.gmailSendMessage(to, subject, bodyText);
  }

  // =========================================================================
  // Notion Database & Page Tools
  // =========================================================================

  async notionSearch(query = '', filterKind = null) {
    if (!this.providerConnectionsEnabled) throw new Error('Notion is disabled in isolated mode.');
    return this.notion.search(query, filterKind);
  }

  async notionQueryDatabase(databaseId, filter = null, sorts = null) {
    if (!this.providerConnectionsEnabled) throw new Error('Notion is disabled in isolated mode.');
    return this.notion.queryDatabase(databaseId, filter, sorts);
  }

  async notionCreatePage(databaseId, title, properties = {}, children = []) {
    this._assertMutationAllowed('notion_create_page');
    if (!this.providerConnectionsEnabled) throw new Error('Notion is disabled in isolated mode.');
    return this.notion.createPage(databaseId, title, properties, children);
  }

  async notionUpdatePage(pageId, properties = {}) {
    this._assertMutationAllowed('notion_update_page');
    if (!this.providerConnectionsEnabled) throw new Error('Notion is disabled in isolated mode.');
    return this.notion.updatePage(pageId, properties);
  }

  async notionAppendBlocks(blockId, blocks = []) {
    this._assertMutationAllowed('notion_append_blocks');
    if (!this.providerConnectionsEnabled) throw new Error('Notion is disabled in isolated mode.');
    return this.notion.appendBlocks(blockId, blocks);
  }

  async spaceKeeperSessionReport(taskKey) {
    return this.spaceKeeper.sessionReport(taskKey);
  }

  async spaceKeeperCapacityStatus() {
    return this.spaceKeeper.capacityStatus();
  }

  // =========================================================================
  // Built-in Aside / REA Browser Tools
  // =========================================================================

  async browserOpen(url) {
    this._assertMutationAllowed('browser_open');
    if (!this.browser) throw new Error('Browser is disabled in isolated mode.');
    return this.browser.launch(url);
  }

  async browserNavigate(url) {
    this._assertMutationAllowed('browser_navigate');
    if (!this.browser) throw new Error('Browser is disabled in isolated mode.');
    return this.browser.navigate(url);
  }

  async browserAria(tabId = null) {
    if (!this.browser) throw new Error('Browser is disabled in isolated mode.');
    return this.browser.getAriaTree(tabId);
  }

  async browserAct(action) {
    this._assertMutationAllowed('browser_act');
    if (!this.browser) throw new Error('Browser is disabled in isolated mode.');
    return this.browser.act(action);
  }

  async browserRead() {
    if (!this.browser) throw new Error('Browser is disabled in isolated mode.');
    return this.browser.readText();
  }

  async browserHistory(action) {
    this._assertMutationAllowed('browser_history');
    if (!this.browser) throw new Error('Browser is disabled in isolated mode.');
    if (typeof this.browser.history !== 'function') return { ok: false, stderr: '브라우저 뒤로/앞으로/새로고침 제어를 사용할 수 없습니다.' };
    return this.browser.history(action);
  }

  async browserRecipe(recipeName, tabId = null) {
    this._assertMutationAllowed('browser_recipe');
    if (!this.browser) throw new Error('Browser is disabled in isolated mode.');
    return this.browser.recipePlay(recipeName, tabId);
  }

  async browserStatus() {
    if (!this.browser) return { enabled: false };
    return this.browser.getStatus();
  }

  // =========================================================================
  // Passkey & Credential Vault Access
  // =========================================================================

  async vaultRequestCredential(service) {
    this._assertMutationAllowed('vault_get_credential');
    return this.vault.requestAccessForAi(service);
  }

  // =========================================================================
  // Chrome & Firefox Browser Workspace Tools
  // =========================================================================

  async browserWorkspaceList(browser = 'chrome') {
    return this.browserWorkspace.listTabs(browser);
  }

  async browserWorkspaceSnapshot(name, browser = 'chrome') {
    this._assertMutationAllowed('browser_workspace_snapshot');
    return this.browserWorkspace.snapshot(name, browser);
  }

  async browserWorkspaceRestore(name, browser = 'chrome') {
    this._assertMutationAllowed('browser_workspace_restore');
    return this.browserWorkspace.restore(name, browser);
  }

  async browserWorkspaceFocus(query) {
    this._assertMutationAllowed('browser_workspace_focus');
    return this.browserWorkspace.focusTab(query);
  }

  async browserWorkspaceOpen(url, browser = 'chrome') {
    this._assertMutationAllowed('browser_workspace_open');
    return this.browserWorkspace.openTab(url, browser);
  }

  async browserWorkspaceListSaved() {
    return this.browserWorkspace.listWorkspaces();
  }
}

module.exports = { ToolRegistry, shellInvocation, storageBudgetForCommand };
