/**
 * @project My-Codex
 * @provenance:rogan-core
 * @author Rogan Kim (GeunHu Kim) & AI Architect
 * @license MIT
 * @description Sovereign Codex Agent Engine running multi-turn execution loops with autonomous priority fallback.
 */
'use strict';

const { ToolRegistry } = require('../tools/ToolRegistry.js');
const { PriorityChainEngine } = require('../priority/PriorityChainEngine.js');
const { AuthManager } = require('../auth/AuthManager.js');
const { SessionStore } = require('./SessionStore.js');
const { SkillManager } = require('./SkillManager.js');
const { ParallelDispatcher } = require('./ParallelDispatcher.js');
const { OwnershipLock } = require('./OwnershipLock.js');
const { WorkspaceExecutionLease } = require('./WorkspaceExecutionLease.js');
const { HandoffAdapter } = require('./HandoffAdapter.js');
const { parseReasoningEffort } = require('./ReasoningEffort.js');
const { AccountRouterModuleSlot } = require('../features/provider/AccountRouterModuleSlot.js');
const path = require('node:path');
const os = require('node:os');

const MUTATION_TOOL_NAMES = new Set([
  'exec_command', 'bash', 'write_file', 'edit_file', 'apply_patch',
  'google_drive_create', 'google_drive_update', 'gmail_send',
  'notion_create_page', 'notion_update_page', 'notion_append_blocks',
  'browser_open', 'browser_navigate', 'browser_act', 'browser_recipe', 'browser_history',
  'vault_get_credential',
  'browser_workspace_restore', 'browser_workspace_focus', 'browser_workspace_open'
]);

function isMutationToolName(name) {
  return MUTATION_TOOL_NAMES.has(name);
}

function providerFailureCategory(error) {
  const message = String(error?.message || error || '');
  if (/\b429\b|too many requests|quota|rate[\s_-]?limit|resource.?exhausted/i.test(message)) return 'quota_rate_limit';
  if (/unauthori[sz]ed|authentication required|not logged in|\b401\b|invalid credential/i.test(message)) return 'authentication';
  if (/model_not_found|model.{0,30}(?:unavailable|not found|not supported)|unsupported model/i.test(message)) return 'model_unavailable';
  if (/sandbox|permission denied|not permitted|access denied/i.test(message)) return 'sandbox_permission_blocked';
  if (/network|\b(?:econn|enotfound|ehostunreach|etimedout|eai_again)\b|fetch failed|connection refused/i.test(message)) return 'network_unavailable';
  return 'provider_failure';
}

function safeProviderModel(model) {
  if (typeof model !== 'string') return '';
  const safe = model.replace(/[^A-Za-z0-9._+:/ -]/g, '').trim().slice(0, 80);
  return safe;
}

function safeProviderTier(tier) {
  const tierName = typeof tier?.name === 'string' ? tier.name.replace(/[^A-Za-z0-9._+:/ -]/g, '').trim().slice(0, 40) : '';
  return tierName || 'unknown';
}

class AgentEngine {
  constructor(options = {}) {
    this.isolated = options.isolated === true;
    this.dataDir = path.resolve(options.dataDir || path.join(os.homedir(), '.my-codex'));
    if (this.isolated && !options.dataDir) throw new Error('An explicit temporary dataDir is required in isolated mode.');
    const insideDataDir = value => {
      const resolved = path.resolve(value);
      const relative = path.relative(this.dataDir, resolved);
      if (this.isolated && (relative === '..' || relative.startsWith(`..${path.sep}`) || path.isAbsolute(relative))) throw new Error('Isolated runtime paths must stay inside dataDir.');
      return resolved;
    };
    this.workspaceDir = insideDataDir(options.workspaceDir || (this.isolated ? path.join(this.dataDir, 'workspace') : process.cwd()));
    this.tools = new ToolRegistry({
      workspaceDir: this.workspaceDir,
      sandboxRoot: this.isolated ? this.dataDir : null,
      commandRunner: options.commandRunner,
      approvalPolicy: options.approvalPolicy || 'on-request',
      browser: options.browser,
      browserEnabled: !this.isolated,
      providerConnectionsEnabled: !this.isolated,
      connectorOptions: this.isolated ? { storageDir: path.join(this.dataDir, 'providers'), clientConfigFile: false, readEnvironment: false } : {},
      vaultOptions: this.isolated ? { vaultDir: path.join(this.dataDir, 'vault') } : {},
      browserWorkspaceOptions: this.isolated ? { enabled: false, workspaceDir: path.join(this.dataDir, 'browser-workspaces') } : {}
    });
    this.priorityChain = new PriorityChainEngine({ configDir: insideDataDir(options.configDir || (this.isolated ? path.join(this.dataDir, 'config') : this.dataDir)), seedDefaults: !this.isolated, notify: options.notify, isTierReady: options.isTierReady });
    this.auth = new AuthManager({ authFile: insideDataDir(options.authFile || (this.isolated ? path.join(this.dataDir, 'auth', 'auth.json') : path.join(this.dataDir, 'auth.json'))), seedDefaults: !this.isolated });
    this.sessions = new SessionStore({ storageDir: insideDataDir(options.storageDir || path.join(this.dataDir, 'sessions')) });
    
    // Core Rogan-requested systems
    this.skills = new SkillManager(this.isolated ? {
      workspaceDir: this.workspaceDir,
      globalSkillsDir: path.join(this.dataDir, 'skills'),
      sharedSkillsDir: false,
      pluginCacheDir: false,
      watchEnabled: false
    } : { workspaceDir: this.workspaceDir, watchEnabled: options.watchSkills !== false });
    // Dispatched tasks get their own session and run serially in this workspace.
    this.dispatcher = new ParallelDispatcher({
      autoStart: options.dispatcherAutoStart ?? !this.isolated,
      maxGlobalConcurrency: 1,
      executeTask: task => this._executeDispatchedTask(task)
    });
    this.ownership = new OwnershipLock({ workspaceDir: this.workspaceDir });
    this.workspaceExecutionLease = new WorkspaceExecutionLease({
      lockRoot: path.join(this.dataDir, 'workspace-leases')
    });
    this.handoff = options.handoffStorageDir
      ? new HandoffAdapter({ storageDir: insideDataDir(options.handoffStorageDir), gdriveHandoffDir: false })
      : new HandoffAdapter(this.isolated
      ? { storageDir: path.join(this.dataDir, 'handoff'), gdriveHandoffDir: false }
      : {});
    this.providerAdapter = options.providerAdapter || null;
    this.accountRouterModuleSlot = new AccountRouterModuleSlot({ projectRoot: path.resolve(__dirname, '../..') });

    this.currentSession = null;
    this.conversationHistory = [];
  }

  initSession(metadata = {}) {
    const activeTier = this.priorityChain.resolveActiveTier();
    if (!activeTier && !metadata.model) {
      throw new Error('사용 가능한 우선순위 계정이 없습니다. 계정 상태와 사용 한도를 확인해 주세요.');
    }
    this.currentSession = this.sessions.createSession({
      workspaceDir: metadata.workspaceDir || this.workspaceDir,
      model: metadata.model || activeTier?.model,
      provider: metadata.provider || activeTier?.provider,
      ...metadata
    });
    this.conversationHistory = metadata.initialHistory ? [...metadata.initialHistory] : [];
    return this.currentSession;
  }

  loadResumedSession(sessionData) {
    this.workspaceDir = sessionData.cwd || this.workspaceDir;
    this.tools.setWorkspace(this.workspaceDir);
    this.ownership = new OwnershipLock({ workspaceDir: this.workspaceDir });

    this.currentSession = {
      sessionId: sessionData.sessionId || sessionData.id,
      resumedFrom: sessionData.source,
      title: sessionData.title,
      workspaceDir: this.workspaceDir,
      model: sessionData.model
    };

    // Load past turns into conversation history so context is preserved!
    this.conversationHistory = (sessionData.turns || []).map(t => ({
      role: t.role,
      content: t.content
    }));

    return this.currentSession;
  }

  loadInternalSession(sessionData) {
    if (!sessionData || sessionData.source !== 'internal' || typeof sessionData.sessionId !== 'string'
      || !/^ses_[a-f0-9]{16}$/.test(sessionData.sessionId)) {
      throw new Error('Invalid internal session.');
    }
    return this.loadResumedSession({ ...sessionData, id: sessionData.sessionId });
  }

  /**
   * Run one conversational agent turn with streaming callbacks and tool dispatching
   */
  async executeTurn(userPrompt, callbacks = {}) {
    return this.workspaceExecutionLease.run(
      this.workspaceDir,
      this.currentSession?.sessionId || 'router-provider-discovery',
      async () => {
        await this._ensureAccountRouterTier();
        if (!this.currentSession) this.initSession();
        return this._executeTurn(userPrompt, callbacks);
      }
    );
  }

  async _ensureAccountRouterTier() {
    if (this.isolated || this.priorityChain.chain.tiers.some(tier => tier.provider === 'account-router')) return false;
    if (Date.now() < (this.accountRouterDiscoveryRetryAt || 0)) return false;
    this.accountRouterDiscoveryRetryAt = Date.now() + 15_000;
    try {
      const accountRouterAdapter = await this._getAccountRouterAdapter();
      const chain = await accountRouterAdapter.getChain();
      const configured = chain.enabled && chain.accounts.some(account => account.enabled !== false &&
        account.provider && account.provider !== 'demo' && account.provider !== 'unconfigured' &&
        account.model && account.model !== 'unconfigured');
      if (!configured) return false;
      this.priorityChain.upsertTier({
        id: 'account-router-local',
        name: 'AI Account Router (Local)',
        provider: 'account-router',
        model: 'auto',
        account: 'account-router-local',
        enabled: true,
        description: 'Automatic local fallback; provider profiles remain managed by AI Account Router.'
      });
      return true;
    } catch (_) {
      return false;
    }
  }

  _requiresToolApproval(call) {
    if (this.tools.approvalPolicy === 'read-only') return isMutationToolName(call?.name);
    if (this.tools.approvalPolicy === 'never') return false;
    return !['read_file', 'list_files', 'search_files', 'gmail_list', 'gmail_read', 'google_drive_list', 'google_drive_read', 'notion_search', 'notion_query', 'browser_aria', 'browser_read', 'browser_status', 'spacekeeper_session_report', 'spacekeeper_capacity_status'].includes(call?.name);
  }

  async _getAccountRouterAdapter() {
    // Keep the injected adapter seam for isolated/synthetic callers; production
    // resolves the allowlisted module by its current source hash on each call.
    if (this.accountRouterAdapter) return this.accountRouterAdapter;
    return (await this.accountRouterModuleSlot.load()).adapter;
  }

  async _requestToolApproval(call, callbacks) {
    const sessionId = this.currentSession?.sessionId;
    const requestId = require('node:crypto').randomUUID();
    const approve = callbacks.requestToolApproval;
    if (typeof approve !== 'function') throw new Error(`Approval unavailable; blocked tool call '${call.name}'.`);
    const accepted = await approve({ requestId, sessionId, name: call.name, args: call.args || {} });
    if (this.currentSession?.sessionId !== sessionId || accepted !== true) throw new Error(`Tool call '${call.name}' was not approved for this session.`);
    return true;
  }

  async _executeDispatchedTask(task) {
    if (!task || typeof task.prompt !== 'string' || !task.prompt.trim()) {
      return { status: 'failed', error: '실행할 prompt가 비어 있습니다.' };
    }
    const taskKey = String(task.id || `task-${Date.now()}`).replace(/[^A-Za-z0-9._-]/g, '_').slice(0, 128);
    const worker = new AgentEngine({
      isolated: this.isolated,
      dataDir: this.dataDir,
      workspaceDir: this.workspaceDir,
      storageDir: this.sessions.storageDir,
      configDir: this.priorityChain.configDir,
      authFile: this.auth.authFile,
      providerAdapter: this.providerAdapter,
      isTierReady: tier => this.priorityChain.isTierReady(tier),
      approvalPolicy: this.tools.approvalPolicy,
      watchSkills: false,
      dispatcherAutoStart: false,
      handoffStorageDir: path.join(this.dataDir, 'dispatcher-handoff', taskKey)
    });
    worker.priorityChain = this.priorityChain;
    const evidence = {
      toolNames: [],
      attemptedCount: 0,
      successfulCount: 0,
      provider: null,
      model: null,
      tierId: null,
      tierName: null
    };
    const startedTools = new Map();
    const safeToolName = name => /^[a-z][a-z0-9_]{0,63}$/i.test(String(name || '')) ? String(name) : 'unknown_tool';
    const callbacks = {
      onTierResolved: tier => {
        evidence.provider = String(tier?.provider || '').slice(0, 64) || null;
        evidence.model = String(tier?.model || '').slice(0, 128) || null;
        evidence.tierId = String(tier?.id || '').slice(0, 128) || null;
        evidence.tierName = String(tier?.name || '').slice(0, 128) || null;
      },
      onToolStart: call => {
        const name = safeToolName(call?.name);
        evidence.attemptedCount++;
        if (!evidence.toolNames.includes(name)) evidence.toolNames.push(name);
        const key = String(call?.id || `${name}:${evidence.attemptedCount}`);
        startedTools.set(key, name);
      },
      onToolEnd: ({ call, result } = {}) => {
        const name = safeToolName(call?.name);
        const key = String(call?.id || '');
        const hadStart = startedTools.has(key);
        if (!hadStart) {
          evidence.attemptedCount++;
          if (!evidence.toolNames.includes(name)) evidence.toolNames.push(name);
        }
        startedTools.delete(key);
        const successful = result?.ok !== false
          && !result?.error
          && result?.blocked !== true
          && (name === 'exec_command' || name === 'bash'
            ? result?.exitCode === 0
            : name === 'file_change' || hadStart);
        if (successful) evidence.successfulCount++;
      }
    };
    try {
      const session = worker.initSession({ title: task.title, workspaceDir: this.workspaceDir });
      const response = await worker.executeTurn(task.prompt, callbacks);
      worker.sessions.appendItem(session.sessionId, { type: 'session_metadata', metadata: { executionEvidence: evidence } });
      if (typeof response?.content !== 'string' || !response.content.trim()) {
        return { status: 'blocked', reason: 'AgentEngine이 빈 응답을 반환했습니다.', sessionId: session.sessionId, result: response?.content || '', executionEvidence: evidence };
      }
      if (task.requireToolExecution !== false && evidence.successfulCount < 1) {
        return { status: 'blocked', reason: '완료된 Codex 도구 실행이 확인되지 않았습니다.', result: response.content, sessionId: session.sessionId, executionEvidence: evidence };
      }
      return { status: 'completed', result: response.content, sessionId: session.sessionId, executionEvidence: evidence };
    } catch (error) {
      const message = error?.message || String(error);
      const blocked = /작업공간은 다른 Only Chat 작업이 사용 중|승인|차단/.test(message);
      const sessionId = worker.currentSession?.sessionId || null;
      if (sessionId) {
        try { worker.sessions.appendItem(sessionId, { type: 'session_metadata', metadata: { executionEvidence: evidence } }); } catch (_) {}
      }
      return blocked
        ? { status: 'blocked', reason: message, result: '', sessionId, executionEvidence: evidence }
        : { status: 'failed', error: message, result: '', sessionId, executionEvidence: evidence };
    } finally {
      worker.dispatcher.stop();
      worker.skills.stopWatching();
    }
  }

  async _executeTurn(userPrompt, callbacks = {}) {
    if (!this.currentSession) {
      this.initSession();
    }

    const managerMode = callbacks.managerMode === true;
    const managerSystemMessage = callbacks.managerSystemMessage;
    const reasoningEffort = parseReasoningEffort(callbacks.reasoningEffort);
    if (!reasoningEffort) throw new Error('Unsupported reasoning effort.');
    if (managerMode && (!managerSystemMessage || managerSystemMessage.role !== 'system' || typeof managerSystemMessage.content !== 'string')) {
      throw new Error('Manager mode requires a system message built from the live capability registry.');
    }

    const {
      onTierResolved,
      onReasoningDelta,
      onMessageDelta,
      onToolStart,
      onToolOutput,
      onToolEnd,
      onTurnComplete
    } = callbacks;

    // 1. Dynamic Live Skill & Shortcut Resolution (No new chat required!)
    const { text: resolvedPrompt, injectedSkills } = this.skills.resolvePromptShortcuts(userPrompt);
    if (injectedSkills.length > 0 && onReasoningDelta) {
      onReasoningDelta(`[SkillManager] 실시간 핫리로드 스킬 주입: ${injectedSkills.map(s => '$' + s).join(', ')}`);
    }

    // 2. Save durable checkpoint for restart/resume & Windows sync
    this.handoff.saveCheckpoint({
      sessionId: this.currentSession.sessionId,
      lastPrompt: userPrompt,
      workspaceDir: this.workspaceDir,
      injectedSkills
    });

    // Record user prompt
    this.conversationHistory.push({ role: 'user', content: resolvedPrompt });
    this.sessions.appendItem(this.currentSession.sessionId, {
      type: 'user_message',
      content: userPrompt,
      resolvedContent: resolvedPrompt,
      injectedSkills,
      reasoningEffort
    });

    let turnSuccess = false;
    let attempts = 0;
    let lastProviderFailure = null;
    const maxAttempts = this.priorityChain.chain.tiers.length;

    while (!turnSuccess && attempts < maxAttempts) {
      const activeTier = this.priorityChain.resolveActiveTier();
      if (!activeTier) break;
      attempts++;
      if (onTierResolved) onTierResolved(activeTier);

      try {
        // Run inference against active tier
        const inferenceHistory = managerMode
          ? [managerSystemMessage, ...this.conversationHistory]
          : this.conversationHistory;
        let response = await this._callProviderWithFallback(activeTier, inferenceHistory, {
          onReasoningDelta,
          onMessageDelta: managerMode ? null : onMessageDelta,
          onToolStart,
          onToolOutput,
          onToolEnd
        }, { reasoningEffort });
        this.priorityChain.reportTierSuccess(activeTier.id);

        // Manager requests never enter the application's tool execution loop.
        let managerToolCallBlocked = false;
        if (response.toolCalls && response.toolCalls.length > 0) {
          if (managerMode) {
            managerToolCallBlocked = true;
            response = {
              content: '관리자 모드는 제안 전용입니다. 요청된 도구 실행은 수행하지 않았습니다. 필요한 작업과 승인 단계를 안내해 주세요.',
              toolCalls: []
            };
            if (onMessageDelta) onMessageDelta(response.content);
          } else {
            if (response.protocol === 'openai-compatible') {
              this.conversationHistory.push({
                role: 'assistant',
                content: response.content || null,
                tool_calls: response.toolCalls.map(call => ({
                  id: call.id,
                  type: 'function',
                  function: { name: call.name, arguments: JSON.stringify(call.args || {}) }
                }))
              });
            }
            for (const call of response.toolCalls) {
              if (this.tools.approvalPolicy === 'read-only' && isMutationToolName(call?.name)) {
                const blocked = { error: `Tool call '${call.name}' is blocked under read-only policy.`, blocked: true };
                if (onToolEnd) onToolEnd({ call, result: blocked });
                this.sessions.appendItem(this.currentSession.sessionId, { type: 'tool_result', tool: call.name, result: blocked });
                continue;
              }
              if (this._requiresToolApproval(call)) {
                try {
                  await this._requestToolApproval(call, callbacks);
                } catch (approvalError) {
                  const blocked = { error: approvalError.message, blocked: true };
                  if (onToolEnd) onToolEnd({ call, result: blocked });
                  this.sessions.appendItem(this.currentSession.sessionId, { type: 'tool_result', tool: call.name, result: blocked });
                  continue;
                }
              }
              if (onToolStart) onToolStart(call);

              let toolResult;
              try {
                toolResult = await this._executeToolCall(call, onToolOutput);
              } catch (toolErr) {
                toolResult = { error: toolErr.message };
              }

              if (onToolEnd) onToolEnd({ call, result: toolResult });

              // Append tool execution to history and session
              this.conversationHistory.push({
                role: 'tool',
                tool_call_id: call.id,
                content: typeof toolResult === 'string' ? toolResult : JSON.stringify(toolResult)
              });
              this.sessions.appendItem(this.currentSession.sessionId, {
                type: 'tool_result',
                tool: call.name,
                result: toolResult
              });
            }

            // Follow-up recursive loop if more actions are required
            return this.executeTurn('', callbacks);
          }
        }

        // Complete turn
        if (managerMode && onMessageDelta && !managerToolCallBlocked) onMessageDelta(response.content);
        this.conversationHistory.push({ role: 'assistant', content: response.content });
        this.sessions.appendItem(this.currentSession.sessionId, {
          type: 'assistant_message',
          content: response.content
        });

        if (onTurnComplete) onTurnComplete({ tier: activeTier, response });
        turnSuccess = true;
        return response;

      } catch (err) {
        const category = providerFailureCategory(err);
        const model = safeProviderModel(activeTier.model);
        console.warn(`[AgentEngine] Turn attempt failed: category=${category} model=${model || 'unknown'} tier=${safeProviderTier(activeTier)}`);
        const rank = Number.isFinite(activeTier.tier) ? activeTier.tier : null;
        lastProviderFailure = { category, model, rank };
        this.priorityChain.reportTierFailure(activeTier.id, err);
        // Continue loop to try next fallback tier
      }
    }

    if (!turnSuccess) {
      if (!this.priorityChain.chain.enabled) {
        throw new Error('수동 선택 계정을 사용할 수 없습니다. 해당 계정의 로그인과 한도를 확인하거나 자동 우선순위를 켜 주세요.');
      }
      const failure = new Error('All eligible provider tiers failed.');
      failure.category = lastProviderFailure?.category || 'provider_failure';
      if (lastProviderFailure?.model) failure.model = lastProviderFailure.model;
      if (Number.isFinite(lastProviderFailure?.rank)) failure.rank = lastProviderFailure.rank;
      throw failure;
    }
  }

  async _executeToolCall(call, onOutput) {
    const { name, args } = call;
    if (this.tools.approvalPolicy === 'read-only' && isMutationToolName(name)) {
      throw new Error(`Tool call '${name}' is blocked under read-only policy.`);
    }
    const targetFile = args.path || args.file_path;

    // File Ownership Lock guard to prevent concurrent file corruption
    if (targetFile && (name === 'write_file' || name === 'edit_file')) {
      const lockRes = this.ownership.acquireLocks(this.currentSession?.sessionId || 'default', [targetFile]);
      if (!lockRes.acquired) {
        throw new Error(lockRes.reason);
      }
    }

    try {
      switch (name) {
        case 'exec_command':
        case 'bash':
          return await this.tools.execCommand(args.command || args.cmd, onOutput, {
            cwd: args.cwd,
            storagePeakGiB: args.storagePeakGiB,
            storageTask: `onlychat-${this.currentSession?.sessionId || 'command'}`
          });
        case 'read_file':
          return await this.tools.readFile(args.path || args.file_path, args.start_line, args.end_line);
        case 'write_file':
          return await this.tools.writeFile(args.path || args.file_path, args.content);
        case 'edit_file':
          return await this.tools.editFile(args.path || args.file_path, args.target, args.replacement);
        case 'apply_patch':
          return await this.tools.applyPatch(args.patch);

        // Google Workspace Tools (Drive & Gmail)
        case 'google_drive_list':
          return await this.tools.googleDriveList(args);
        case 'google_drive_read':
          return await this.tools.googleDriveRead(args.fileId);
        case 'google_drive_create':
          return await this.tools.googleDriveCreate(args.name, args.mimeType, args.content, args.parentId);
        case 'google_drive_update':
          return await this.tools.googleDriveUpdate(args.fileId, args.content, args.mimeType);
        case 'gmail_list':
          return await this.tools.gmailList(args);
        case 'gmail_read':
          return await this.tools.gmailRead(args.messageId);
        case 'gmail_send':
          return await this.tools.gmailSend(args.to, args.subject, args.body || args.bodyText);

        // Notion Database & Page Tools
        case 'notion_search':
          return await this.tools.notionSearch(args.query, args.filterKind);
        case 'notion_query':
          return await this.tools.notionQueryDatabase(args.databaseId, args.filter, args.sorts);
        case 'notion_create_page':
          return await this.tools.notionCreatePage(args.databaseId, args.title, args.properties, args.children);
        case 'notion_update_page':
          return await this.tools.notionUpdatePage(args.pageId, args.properties);
        case 'notion_append_blocks':
          return await this.tools.notionAppendBlocks(args.blockId, args.blocks);

        // Space Keeper's task-keyed, read-only storage report.
        case 'spacekeeper_session_report':
          return await this.tools.spaceKeeperSessionReport(args.taskKey);
        case 'spacekeeper_capacity_status':
          return await this.tools.spaceKeeperCapacityStatus();

        // Built-in Aside / REA Browser Tools
        case 'browser_open':
          return await this.tools.browserOpen(args.url || 'https://google.com');
        case 'browser_navigate':
          return await this.tools.browserNavigate(args.url);
        case 'browser_aria':
          return await this.tools.browserAria(args.tabId);
        case 'browser_act':
          return await this.tools.browserAct(args.action);
        case 'browser_read':
          return await this.tools.browserRead();
        case 'browser_recipe':
          return await this.tools.browserRecipe(args.name || args.recipe, args.tabId);
        case 'browser_status':
          return await this.tools.browserStatus();

        // Passkey & Credential Vault Tool
        case 'vault_get_credential':
          return await this.tools.vaultRequestCredential(args.service || args.name);

        default:
          throw new Error(`Unknown tool: ${name}`);
      }
    } finally {
      if (targetFile && (name === 'write_file' || name === 'edit_file')) {
        this.ownership.releaseLocks(this.currentSession?.sessionId || 'default');
      }
    }
  }

  /**
   * Autonomous provider dispatcher (Antigravity CLI / Google OAuth vs ChatGPT / Codex API)
   */
  async _callProviderWithFallback(tier, history, streamingHooks = {}, options = {}) {
    const reasoningEffort = parseReasoningEffort(options.reasoningEffort);
    if (!reasoningEffort) throw new Error('Unsupported reasoning effort.');
    if (tier?.provider === 'account-router') {
      if (this.isolated) throw new Error('AI Account Router is disabled in isolated mode.');
      const accountRouterAdapter = await this._getAccountRouterAdapter();
      return accountRouterAdapter.call(tier, history, streamingHooks, {
        sessionId: this.currentSession?.sessionId,
        workspaceDir: this.workspaceDir,
        reasoningEffort
      });
    }
    if (this.isolated) {
      if (!this.providerAdapter) throw new Error('Provider calls require an injected synthetic adapter in isolated mode.');
      return this.providerAdapter(tier, history, streamingHooks, { reasoningEffort });
    }
    if (!this.providerAdapter) {
      throw new Error(`No live provider adapter is configured for '${tier.provider || tier.id}'. Refusing to return a simulated answer.`);
    }
    return this.providerAdapter(tier, history, streamingHooks, {
      sessionId: this.currentSession?.sessionId,
      workspaceDir: this.workspaceDir,
      reasoningEffort
    });
  }

  verifyMetamorphicProviderReload(context) {
    return this.accountRouterModuleSlot.verifyReload(context);
  }

  getMetamorphicProviderStatus() {
    return this.accountRouterModuleSlot.status();
  }
}

module.exports = { AgentEngine, providerFailureCategory };
