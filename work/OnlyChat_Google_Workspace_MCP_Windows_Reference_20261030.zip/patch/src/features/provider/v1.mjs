const DEFAULT_BASE_URL = 'http://127.0.0.1:18880';
const TOOL_NAMES = Object.freeze([
  'exec_command', 'bash', 'read_file', 'write_file', 'edit_file', 'apply_patch',
  'google_drive_list', 'google_drive_read', 'google_drive_create', 'google_drive_update', 'gmail_list', 'gmail_read', 'gmail_send',
  'notion_search', 'notion_query', 'notion_create_page', 'notion_update_page', 'notion_append_blocks',
  'spacekeeper_session_report', 'spacekeeper_capacity_status', 'browser_open', 'browser_navigate',
  'browser_aria', 'browser_act', 'browser_read', 'browser_recipe', 'browser_status'
]);

function toolDefinitions() {
  return TOOL_NAMES.map(name => ({
    type: 'function',
    function: {
      name,
      description: `Use Only Chat's ${name} capability when the user requests it.`,
      parameters: { type: 'object', properties: {}, additionalProperties: true }
    }
  }));
}

function normalizeBaseUrl(value = DEFAULT_BASE_URL) {
  const url = new URL(value);
  const host = url.hostname.replace(/^\[|\]$/g, '');
  if (url.protocol !== 'http:' || !['127.0.0.1', 'localhost', '::1'].includes(host) ||
      url.username || url.password || url.search || url.hash) {
    throw new Error('Only Chat Account Router accepts loopback HTTP only.');
  }
  return url.toString().replace(/\/$/, '');
}

function parseToolCalls(items) {
  if (!Array.isArray(items)) return [];
  return items.map((item, index) => {
    const fn = item?.function || {};
    let args = fn.arguments ?? item?.args ?? {};
    if (typeof args === 'string') args = JSON.parse(args);
    if (!args || typeof args !== 'object' || Array.isArray(args)) throw new Error('Router returned invalid tool arguments.');
    const name = fn.name || item?.name;
    if (typeof name !== 'string' || !name) throw new Error('Router returned a tool call without a name.');
    if (!TOOL_NAMES.includes(name)) throw new Error('Router requested a tool unavailable to the Account Router provider.');
    return { id: String(item.id || `router-${index}-${name}`), name, args };
  });
}

function createAccountRouterAdapter(options = {}) {
  const baseUrl = normalizeBaseUrl(options.baseUrl);
  const fetchImpl = options.fetch || globalThis.fetch;
  const timeoutMs = options.timeoutMs || 120_000;
  if (typeof fetchImpl !== 'function') throw new TypeError('A fetch implementation is required.');

  async function call(tier, history, hooks = {}, context = {}) {
    if (!Array.isArray(history) || !history.length) throw new Error('Router needs a non-empty conversation history.');
    const signal = context.signal || AbortSignal.timeout(timeoutMs);
    let response;
    try {
      response = await fetchImpl(`${baseUrl}/v1/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          model: tier?.model || 'auto',
          messages: history,
          tools: toolDefinitions(),
          tool_choice: 'auto',
          stream: false
        }),
        signal
      });
    } catch (error) {
      if (error?.name === 'AbortError' || error?.name === 'TimeoutError') throw new Error('AI Account Router request timed out or was cancelled.');
      throw new Error('AI Account Router is unavailable on 127.0.0.1:18880.');
    }
    const body = await response.json().catch(() => null);
    if (!response.ok) {
      const code = body?.error?.code;
      const error = new Error(code === 'provider_unconfigured'
        ? 'AI Account Router has no configured provider account.'
        : `AI Account Router returned HTTP ${response.status}${code ? ` (${code})` : ''}.`);
      error.status = response.status;
      error.code = code || 'router_error';
      throw error;
    }
    const message = body?.choices?.[0]?.message;
    if (!message || (typeof message.content !== 'string' && !Array.isArray(message.tool_calls))) {
      throw new Error('AI Account Router returned an invalid chat completion.');
    }
    const toolCalls = parseToolCalls(message.tool_calls);
    const content = typeof message.content === 'string' ? message.content : '';
    if (content) hooks.onMessageDelta?.(content);
    return { content, toolCalls, usage: body.usage || null, protocol: 'openai-compatible' };
  }

  async function getChain() {
    const response = await fetchImpl(`${baseUrl}/api/v1/account-chain`, {
      headers: { Accept: 'application/json' },
      signal: AbortSignal.timeout(1500)
    });
    const body = await response.json().catch(() => null);
    if (!response.ok || body?.apiVersion !== 1 || !Array.isArray(body.accounts)) throw new Error('AI Account Router account-chain metadata is unavailable.');
    return body;
  }

  return Object.freeze({ baseUrl, getChain, call });
}

export { DEFAULT_BASE_URL, createAccountRouterAdapter, normalizeBaseUrl, parseToolCalls, toolDefinitions };
