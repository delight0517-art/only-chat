/**
 * @project Only Chat (Codex Sovereign Edition)
 * @provenance:rogan-core
 * @author Rogan Kim (GeunHu Kim) & AI Architect
 * @license MIT
 * @description Frontend Client powering Only Chat with M-Oasis Priority Chain,
 * Metamorphic Hot-Reload, Passkey Vault, and Built-in Aside Browser.
 */
'use strict';

const { groupInternalSessions } = window.internalSessionGrouping;
const { hasInternalSessionDragType, mapSessionDropDestination } = window.sessionDropMapping;
const { presentWorkspaceOwnership } = window.workspaceOwnershipPresentation;

let currentSessionId = null;
let activeAssistantCard = null;
let activeTier = null;
let priorityStatus = null;
let threefControlAllowed = false;
let isGenerating = false;
let currentAbortController = null;
let isRecording = false;
let speechRecognition = null;
let pendingUiMorphReload = false;
let uiMorphReloadTimer = null;
const UI_ZOOM_KEY = 'onlyChatUiZoom';
const MIN_UI_ZOOM = 0.8;
const MAX_UI_ZOOM = 1.5;
const FANTASY_WARRIOR_MODE_KEY = 'onlyChatFantasyWarriorMode';
let fantasyWarriorMode = localStorage.getItem(FANTASY_WARRIOR_MODE_KEY) === 'true';
let uiZoom = Math.min(MAX_UI_ZOOM, Math.max(MIN_UI_ZOOM, Number(localStorage.getItem(UI_ZOOM_KEY)) || 1));
document.documentElement.style.zoom = String(uiZoom);
document.documentElement.dataset.theme = fantasyWarriorMode ? 'fantasy' : 'default';

function adjustUiZoom(step) {
  uiZoom = Math.min(MAX_UI_ZOOM, Math.max(MIN_UI_ZOOM, Math.round((uiZoom + step) * 10) / 10));
  document.documentElement.style.zoom = String(uiZoom);
  localStorage.setItem(UI_ZOOM_KEY, String(uiZoom));
}

// DOM Elements
const timeline = document.getElementById('timeline');
const emptyState = document.getElementById('emptyState');
const composerInput = document.getElementById('composerInput');
const managerModeToggle = document.getElementById('managerModeToggle');
const btnSend = document.getElementById('btnSend');
const sessionList = document.getElementById('sessionList');
const pinnedSessionList = document.getElementById('pinnedSessionList');
const codexProjectGroup = document.getElementById('codexProjectGroup');
const projectList = document.getElementById('projectList');
const pinnedSessionGroup = document.getElementById('pinnedSessionGroup');
const titlebarThreadTitle = document.getElementById('titlebarThreadTitle');
const btnSidebarSearch = document.getElementById('btnSidebarSearch');
const sessionTitleSearch = document.getElementById('sessionTitleSearch');
const sidebarScrollable = document.querySelector('.sidebar-scrollable');
const railHomeBtn = document.getElementById('railHomeBtn');
const railProjectsBtn = document.getElementById('railProjectsBtn');
const railHistoryBtn = document.getElementById('railHistoryBtn');

// Drawers & Overlays
const drawerPriority = document.getElementById('drawerPriority');
const drawerSettings = document.getElementById('drawerSettings');
const drawerMorph = document.getElementById('drawerMorph');
const drawerBrowser = document.getElementById('drawerBrowser');
const btnTogglePriority = document.getElementById('btnTogglePriority');
const btnToggleSettings = document.getElementById('btnToggleSettings');
const btnToggleMorph = document.getElementById('btnToggleMorph');
const btnToggleBrowser = document.getElementById('btnToggleBrowser');
const btnClosePriority = document.getElementById('btnClosePriority');
const btnCloseSettings = document.getElementById('btnCloseSettings');
const btnCloseMorph = document.getElementById('btnCloseMorph');
const btnCloseBrowser = document.getElementById('btnCloseBrowser');
const drawerTierList = document.getElementById('drawerTierList');
const morphSlotsList = document.getElementById('morphSlotsList');

// Reference 4 Elements (Usage Quota Popup)
const btnUsageQuota = document.getElementById('btnUsageQuota');
const usageQuotaPopup = document.getElementById('usageQuotaPopup');
const popupUsageSource = document.getElementById('popupUsageSource');
const popupWeeklyLimit = document.getElementById('popupWeeklyLimit');
const popupCredits = document.getElementById('popupCredits');
const btnManageUsage = document.getElementById('btnManageUsage');

// Reference 3 Elements (Model Dropdown, Mic, Orange Button)
const modelPillTrigger = document.getElementById('modelPillTrigger');
const modelSelectorPopup = document.getElementById('modelSelectorPopup');
const activeModelLabel = document.getElementById('activeModelLabel');
const activeModelAccount = document.getElementById('activeModelAccount');
const activeModelVariant = document.getElementById('activeModelVariant');
const MODEL_SELECTION_KEY = 'onlyChatSelectedModel';
let selectedModelId = localStorage.getItem(MODEL_SELECTION_KEY) || 'gpt-6-luna';
const effortPillTrigger = document.getElementById('effortPillTrigger');
const effortSelectorPopup = document.getElementById('effortSelectorPopup');
const activeEffortLabel = document.getElementById('activeEffortLabel');
const effortPopupLevel = document.getElementById('effortPopupLevel');
const effortPopupModel = document.getElementById('effortPopupModel');
const effortSlider = document.getElementById('effortSlider');
const effortLevelButtons = [...document.querySelectorAll('.effort-level-button')];
const reasoningEffortLevels = [
  { label: 'Low', value: 'low' },
  { label: 'Medium', value: 'medium' },
  { label: 'High', value: 'high' },
  { label: 'Extra High', value: 'xhigh' },
  { label: 'Max', value: 'max' }
];
const REASONING_EFFORT_KEY = 'onlyChatReasoningEffort';
let selectedReasoningEffort = localStorage.getItem(REASONING_EFFORT_KEY) || 'low';
const btnMicrophone = document.getElementById('btnMicrophone');

function normalizeUiReasoningEffort(value) {
  return reasoningEffortLevels.find(level => level.value === value)?.value || 'low';
}

function selectReasoningEffort(value) {
  selectedReasoningEffort = normalizeUiReasoningEffort(value);
  const selectedIndex = reasoningEffortLevels.findIndex(level => level.value === selectedReasoningEffort);
  const selected = reasoningEffortLevels[selectedIndex];
  localStorage.setItem(REASONING_EFFORT_KEY, selected.value);
  if (activeEffortLabel) activeEffortLabel.textContent = selected.label;
  if (effortPopupLevel) effortPopupLevel.textContent = selected.label;
  if (effortSlider) effortSlider.value = String(selectedIndex);
  if (effortPillTrigger) effortPillTrigger.title = `다음 채팅 난이도: ${selected.label}`;
  effortLevelButtons.forEach((button, index) => {
    const active = index === selectedIndex;
    button.classList.toggle('selected', active);
    button.setAttribute('aria-pressed', String(active));
  });
}

// Initialize
window.addEventListener('DOMContentLoaded', async () => {
  selectReasoningEffort(selectedReasoningEffort);
  setupEventListeners();
  initMetamorphicLiveStream();
  initPriorityLiveStream();
  initWindowsInboxLiveStream();
  const sessionsLoad = loadSessions();
  startNewSession();
  void Promise.allSettled([
    refreshPriorityStatus(),
    refreshMorphStatus(),
    refreshAdminManagerStatus(),
    refreshConnectorsStatus(),
    refreshVaultList(),
    loadReaApps()
  ]);
  await sessionsLoad;
});

function initPriorityLiveStream() {
  const stream = new EventSource('/api/priority/stream');
  stream.onmessage = event => {
    try {
      const message = JSON.parse(event.data);
      if (message.type !== 'priority_status' || !message.status) return;
      priorityStatus = message.status;
      activeTier = message.status.activeTier;
      renderPriorityMode();
      renderActiveModelSelection();
      renderDrawerTiers();
    } catch (_) {}
  };
}

function initWindowsInboxLiveStream() {
  const stream = new EventSource('/api/evolution/inbox/stream');
  stream.onmessage = event => {
    try {
      const message = JSON.parse(event.data);
      if (message.type === 'windows_changes') renderWindowsInbox(message.status);
    } catch (_) {}
  };
}

function setupEventListeners() {
  document.getElementById('btnRefreshWorkspaceOwnership')?.addEventListener('click', () => {
    void refreshWorkspaceOwnership();
  });
  const focusSidebarSection = (button, target) => {
    document.querySelectorAll('.activity-rail .rail-item').forEach(item => item.classList.toggle('active', item === button));
    target?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  railHomeBtn?.addEventListener('click', () => {
    document.querySelectorAll('.activity-rail .rail-item').forEach(item => item.classList.toggle('active', item === railHomeBtn));
    sidebarScrollable?.scrollTo({ top: 0, behavior: 'smooth' });
  });
  railProjectsBtn?.addEventListener('click', () => focusSidebarSection(railProjectsBtn, codexProjectGroup));
  railHistoryBtn?.addEventListener('click', () => focusSidebarSection(railHistoryBtn, sessionList?.closest('.sidebar-nav-group')));
  document.getElementById('priorityAutoToggle')?.addEventListener('change', event => setAutomaticPriority(event.currentTarget.checked));
  document.getElementById('fantasyWarriorModeToggle')?.addEventListener('change', event => {
    fantasyWarriorMode = event.currentTarget.checked;
    localStorage.setItem(FANTASY_WARRIOR_MODE_KEY, String(fantasyWarriorMode));
    document.documentElement.dataset.theme = fantasyWarriorMode ? 'fantasy' : 'default';
    renderDrawerTiers();
    showMorphToast(fantasyWarriorMode ? '판타지 전사 모드가 켜졌습니다.' : '기본 Only Chat 디자인으로 돌아왔습니다.');
  });

  // Send / Stop action
  btnSend.addEventListener('click', () => {
    if (isGenerating) {
      abortActiveTurn();
    } else {
      handleSend();
    }
  });

  composerInput.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!isGenerating) handleSend();
    }
  });

  document.getElementById('btnNewChat').addEventListener('click', startNewSession);

  btnSidebarSearch.addEventListener('click', () => {
    if (sessionTitleSearch.hidden) {
      sessionTitleSearch.hidden = false;
      btnSidebarSearch.setAttribute('aria-expanded', 'true');
      sessionTitleSearch.focus();
    } else {
      sessionTitleSearch.value = '';
      sessionTitleSearch.hidden = true;
      btnSidebarSearch.setAttribute('aria-expanded', 'false');
      renderFilteredSessions();
    }
  });
  sessionTitleSearch.addEventListener('input', renderFilteredSessions);
  sessionTitleSearch.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      e.stopPropagation();
      if (sessionTitleSearch.value) {
        sessionTitleSearch.value = '';
        renderFilteredSessions();
      } else {
        sessionTitleSearch.hidden = true;
        btnSidebarSearch.setAttribute('aria-expanded', 'false');
        btnSidebarSearch.focus();
      }
    }
  });

  // Session Filter Bar (All / Codex / AGY / Only)
  document.querySelectorAll('.filter-tab-pill').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-tab-pill').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter = btn.getAttribute('data-filter');
      renderFilteredSessions();
    });
  });

  // Reference 4: Circle with Diamond Usage Popup toggle
  btnUsageQuota.addEventListener('click', e => {
    e.stopPropagation();
    usageQuotaPopup.classList.toggle('open');
    modelSelectorPopup.classList.remove('open');
  });

  btnManageUsage.addEventListener('click', () => {
    usageQuotaPopup.classList.remove('open');
    drawerPriority.classList.add('open');
  });

  // Reference 3: Model Selector Popup toggle & selection
  modelPillTrigger.addEventListener('click', e => {
    e.stopPropagation();
    modelSelectorPopup.classList.toggle('open');
    effortSelectorPopup?.classList.remove('open');
    usageQuotaPopup.classList.remove('open');
  });

  effortPillTrigger?.addEventListener('click', e => {
    e.stopPropagation();
    effortSelectorPopup.classList.toggle('open');
    modelSelectorPopup.classList.remove('open');
    usageQuotaPopup.classList.remove('open');
    effortPillTrigger.setAttribute('aria-expanded', String(effortSelectorPopup.classList.contains('open')));
    if (effortPopupModel) effortPopupModel.textContent = activeModelLabel?.textContent || 'Default';
  });
  effortSlider?.addEventListener('input', () => {
    const index = Number(effortSlider.value);
    selectReasoningEffort(reasoningEffortLevels[index]?.value);
  });
  effortLevelButtons.forEach(button => {
    button.addEventListener('click', () => {
      const index = Number(button.dataset.effortIndex);
      selectReasoningEffort(reasoningEffortLevels[index]?.value);
    });
  });
  document.getElementById('resetEffort')?.addEventListener('click', event => {
    event.stopPropagation();
    selectReasoningEffort('low');
  });
  effortSelectorPopup?.addEventListener('click', event => event.stopPropagation());

  document.querySelectorAll('.model-option').forEach(opt => {
    opt.addEventListener('click', async () => {
      selectedModelId = opt.dataset.model || 'auto';
      localStorage.setItem(MODEL_SELECTION_KEY, selectedModelId);
      document.querySelectorAll('.model-option').forEach(option => {
        const selected = option === opt;
        option.classList.toggle('selected', selected);
        option.setAttribute('aria-selected', String(selected));
      });
      modelSelectorPopup.classList.remove('open');
      renderActiveModelSelection();
    });
  });

  // Close popups on outside click
  document.addEventListener('click', e => {
    if (!usageQuotaPopup.contains(e.target) && e.target !== btnUsageQuota) {
      usageQuotaPopup.classList.remove('open');
    }
    if (!modelSelectorPopup.contains(e.target) && e.target !== modelPillTrigger) {
      modelSelectorPopup.classList.remove('open');
    }
    if (effortSelectorPopup && !effortSelectorPopup.contains(e.target) && e.target !== effortPillTrigger) {
      effortSelectorPopup.classList.remove('open');
      effortPillTrigger?.setAttribute('aria-expanded', 'false');
    }
  });

  // Reference 3: Microphone Button
  btnMicrophone.addEventListener('click', toggleSpeechInput);

  // Keyboard Shortcuts: Ctrl+, and Cmd+, to open Full-Stage Settings View (Ref User UI)
  window.addEventListener('keydown', e => {
    if (e.metaKey !== e.ctrlKey && !e.altKey && !e.shiftKey && !e.repeat && e.key.toLowerCase() === 'n') {
      e.preventDefault();
      startNewSession();
    } else if ((e.ctrlKey || e.metaKey) && (e.key === '+' || e.code === 'NumpadAdd' || (e.code === 'Equal' && e.shiftKey))) {
      e.preventDefault();
      adjustUiZoom(0.1);
    } else if ((e.ctrlKey || e.metaKey) && (e.key === '-' || e.code === 'NumpadSubtract')) {
      e.preventDefault();
      adjustUiZoom(-0.1);
    } else if ((e.ctrlKey || e.metaKey) && (e.key === ',' || e.code === 'Comma')) {
      e.preventDefault();
      toggleSettingsStage();
    } else if (e.key === 'Escape') {
      // ESC closes settings stage or all open drawers & popups
      if (isSettingsStageOpen()) {
        closeSettingsStage();
      }
      drawerSettings.classList.remove('open');
      drawerPriority.classList.remove('open');
      drawerMorph.classList.remove('open');
      drawerBrowser.classList.remove('open');
      usageQuotaPopup.classList.remove('open');
      modelSelectorPopup.classList.remove('open');
    }
  });

  // Top Titlebar Settings Button opens Full-Stage Settings View
  btnToggleSettings.addEventListener('click', () => toggleSettingsStage());
  btnCloseSettings.addEventListener('click', () => drawerSettings.classList.remove('open'));

  // Full-Stage Settings Controls
  const btnCloseSettingsStage = document.getElementById('btnCloseSettingsStage');
  if (btnCloseSettingsStage) {
    btnCloseSettingsStage.addEventListener('click', () => closeSettingsStage());
  }

  document.getElementById('btnWindowsEvolutionConnect')?.addEventListener('click', async () => {
    const input = document.getElementById('windowsEvolutionPath');
    const status = document.getElementById('windowsEvolutionStatus');
    try {
      const response = await fetch('/api/evolution/configure', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ relayRoot: input?.value.trim() }) });
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.error || '공유 폴더 연결 실패');
      renderWindowsInbox(result.status);
    } catch (error) { if (status) status.textContent = `연결 실패: ${error.message}`; }
  });
  document.getElementById('btnWindowsEvolutionDisable')?.addEventListener('click', async () => {
    const status = document.getElementById('windowsEvolutionStatus');
    try {
      const response = await fetch('/api/evolution/disable', { method: 'POST' });
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.error || '연결 해제 실패');
      renderWindowsInbox(result.status);
    } catch (error) { if (status) status.textContent = `연결 해제 실패: ${error.message}`; }
  });

  // Settings Sub-sidebar Tabs Switching
  document.querySelectorAll('.settings-nav-item').forEach(item => {
    item.addEventListener('click', () => {
      document.querySelectorAll('.settings-nav-item').forEach(i => i.classList.remove('active'));
      item.classList.add('active');
      const tabId = item.getAttribute('data-tab');
      switchSettingsTab(tabId);
      if (tabId === 'general') void refreshWorkspaceOwnership();
    });
  });

  // Settings Search Filtering
  const settingsSearchInput = document.getElementById('settingsSearchInput');
  if (settingsSearchInput) {
    settingsSearchInput.addEventListener('input', e => {
      const q = e.target.value.toLowerCase().trim();
      document.querySelectorAll('.settings-nav-item').forEach(item => {
        const text = item.innerText.toLowerCase();
        item.style.display = text.includes(q) ? 'flex' : 'none';
      });
    });
  }

  // Full Access switch sync in Settings Stage
  const chkFullAccess = document.getElementById('chkFullAccess');
  if (chkFullAccess) {
    chkFullAccess.addEventListener('change', () => {
      const isChecked = chkFullAccess.checked;
      const pill = document.getElementById('btnAccessToggle');
      if (pill) {
        pill.querySelector('.access-text').textContent = isChecked ? 'Full access' : 'Sandbox mode';
        pill.style.opacity = isChecked ? '1' : '0.6';
      }
    });
  }

  // Change projectless folder
  const btnChangeChatFolder = document.getElementById('btnChangeChatFolder');
  if (btnChangeChatFolder) {
    btnChangeChatFolder.addEventListener('click', () => {
      const current = document.getElementById('labelProjectlessFolder').innerText;
      const next = prompt('새 프로젝트리스 대화 저장 폴더 경로를 입력하세요:', current);
      if (next && next.trim()) {
        document.getElementById('labelProjectlessFolder').innerText = next.trim();
      }
    });
  }

  // Stage Vault Save button
  const btnStageVaultSave = document.getElementById('btnStageVaultSave');
  if (btnStageVaultSave) {
    btnStageVaultSave.addEventListener('click', handleStageVaultSave);
  }

  // Drawer toggles
  btnTogglePriority?.addEventListener('click', () => drawerPriority.classList.toggle('open'));
  btnClosePriority.addEventListener('click', () => drawerPriority.classList.remove('open'));

  btnToggleMorph?.addEventListener('click', () => drawerMorph.classList.toggle('open'));
  btnCloseMorph.addEventListener('click', () => drawerMorph.classList.remove('open'));

  // Built-in Browser drawer
  btnToggleBrowser?.addEventListener('click', () => setBrowserPanelOpen(!drawerBrowser.classList.contains('open')));
  btnCloseBrowser.addEventListener('click', () => setBrowserPanelOpen(false));
  document.getElementById('btnBrowserNav').addEventListener('click', () => {
    const url = document.getElementById('browserUrlInput').value.trim();
    navBrowser(url);
  });
  document.getElementById('browserUrlInput').addEventListener('keydown', event => {
    if (event.key === 'Enter') navBrowser(event.currentTarget.value);
  });
  document.getElementById('btnBrowserThreef').addEventListener('click', handleBrowserOpenInThreef);
  document.getElementById('btnBrowserAria').addEventListener('click', handleBrowserAria);
  document.getElementById('btnBrowserRead').addEventListener('click', handleBrowserRead);
  document.getElementById('threefControlEnabled').addEventListener('change', async event => {
    const enabled = event.currentTarget.checked;
    const status = document.getElementById('threefControlStatus');
    const previous = threefControlAllowed;
    threefControlAllowed = false;
    setThreefControlUi(false);
    status.textContent = enabled ? '3F Browser 제어를 켜는 중…' : '3F Browser 제어 꺼짐';
    try {
      const response = await fetch('/api/browser/threef/settings', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ enabled }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || '설정을 저장하지 못했습니다.');
      threefControlAllowed = result.enabled === true;
      setThreefControlUi(threefControlAllowed);
      status.textContent = threefControlAllowed ? '3F Browser 제어 허용됨 · 연결 상태 미확인' : '3F Browser 제어 꺼짐';
      if (threefControlAllowed) { void refreshThreefControlStatus(); window.setTimeout(pollEmbeddedThreefCommands, 0); }
    } catch (error) {
      threefControlAllowed = previous;
      setThreefControlUi(previous);
      status.textContent = error.message;
    }
  });
  document.getElementById('btnThreefRefresh').addEventListener('click', () => { void refreshThreefControlStatus(); });
  for (const button of document.querySelectorAll('[data-browser-action]')) {
    button.addEventListener('click', () => sendBrowserPanelAction(button.dataset.browserAction));
  }
  window.addEventListener('resize', syncNativeBrowserPanel);
  window.addEventListener('scroll', syncNativeBrowserPanel, true);
  drawerBrowser.addEventListener('transitionend', syncNativeBrowserPanel);
  syncNativeBrowserPanel();

  // Connectors (Google & Notion)
  document.getElementById('btnLoginGoogleWorkspace').addEventListener('click', handleGoogleLogin);
  document.getElementById('btnConnectNotion').addEventListener('click', handleNotionConnect);

  // Passkey Vault
  document.getElementById('btnVaultSave').addEventListener('click', handleVaultSave);
  document.getElementById('btnRegisterAccount').addEventListener('click', handleRegisterAccount);

  // Sidebar toggle button in titlebar
  const sidebarEl = document.getElementById('sidebar');
  document.getElementById('btnToggleSidebar').addEventListener('click', () => {
    sidebarEl.style.display = sidebarEl.style.display === 'none' ? 'flex' : 'none';
  });

  // Auto-resize textarea
  composerInput.addEventListener('input', () => {
    composerInput.style.height = 'auto';
    composerInput.style.height = Math.min(180, composerInput.scrollHeight) + 'px';
    applyPendingUiMorphReloadWhenSafe();
  });
  ['attachmentPicker', 'folderPicker'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', applyPendingUiMorphReloadWhenSafe);
  });
}

function setPrompt(text) {
  composerInput.value = text;
  composerInput.focus();
  composerInput.dispatchEvent(new Event('input'));
}

// ============================================================================
// Priority Status & Quota Management (Ref 4)
// ============================================================================

async function refreshPriorityStatus() {
  try {
    const res = await fetch('/api/status');
    const data = await res.json();
    priorityStatus = data;
    activeTier = data.activeTier;
    const workspaceRootInput = document.getElementById('settingsCwdInput');
    if (workspaceRootInput && typeof data.workspaceDir === 'string') {
      workspaceRootInput.value = data.workspaceDir;
      workspaceRootInput.readOnly = true;
      workspaceRootInput.title = '현재 실행 중인 에이전트의 실제 작업 폴더입니다.';
    }
    renderPriorityMode();
    renderActiveModelSelection();

    for (const row of document.querySelectorAll('.provider-compact-row')) {
      const isCodex = row.dataset.providerId === 'codex-cli';
      const status = data.providers?.find(item => item.id === data.activeTier?.id);
      const circle = row.querySelector('.provider-status-circle');
      const label = row.querySelector('.provider-type-sub');
      if (!isCodex) {
        row.hidden = true;
      } else if (status) {
        row.hidden = false;
        if (circle) { circle.classList.toggle('active', Boolean(status.connected)); circle.title = status.connected ? 'Connected' : status.message; }
        if (label) label.textContent = status.connected ? 'Connected through Codex CLI' : status.available ? 'Codex CLI sign-in required' : 'Codex CLI unavailable';
      }
    }

    // Update Reference 4 (Popup Card)
    const provider = activeTier?.providerReady;
    if (popupUsageSource) popupUsageSource.textContent = 'Codex CLI';
    if (popupWeeklyLimit) popupWeeklyLimit.textContent = provider
      ? (provider.connected ? 'Connected' : provider.available ? 'Sign-in required' : 'Unavailable')
      : tierQuotaLabel(activeTier);
    if (popupCredits) popupCredits.textContent = 'Usage not reported';

    renderDrawerTiers();
  } catch (err) {
    console.warn('Failed to load priority status:', err);
  }
}

function renderPriorityMode() {
  if (!priorityStatus) return;
  const automatic = priorityStatus.enabled === true;
  const toggle = document.getElementById('priorityAutoToggle');
  const label = document.getElementById('priorityAutoLabel');
  const description = document.getElementById('priorityModeDescription');
  if (toggle) toggle.checked = automatic;
  if (label) label.textContent = automatic ? '켜짐' : '꺼짐 · 수동';
  if (description) description.textContent = automatic
    ? '한도 10% 이하 또는 오류가 감지되면 다음 계정으로 전환'
    : '직접 선택한 계정만 사용 · 실패 시 자동 전환 없음';
  toggle?.closest('.priority-auto-control')?.classList.toggle('manual', !automatic);
  for (const badge of document.querySelectorAll('.priority-mode-badge')) {
    badge.textContent = automatic ? '자동 우선순위 켜짐' : '수동 계정 선택';
  }
}

async function setAutomaticPriority(enabled) {
  const toggle = document.getElementById('priorityAutoToggle');
  try {
    const res = await fetch('/api/priority/mode', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ enabled })
    });
    const result = await res.json();
    if (!res.ok || !result.ok) throw new Error(result.error || `모드 변경 실패 (${res.status})`);
    priorityStatus = result.status;
    activeTier = result.status.activeTier;
    renderPriorityMode();
    renderActiveModelSelection();
    renderDrawerTiers();
    showMorphToast(enabled ? '자동 우선순위 켜짐' : '자동 우선순위 꺼짐 · 수동 계정 선택 모드');
  } catch (error) {
    if (toggle) toggle.checked = priorityStatus?.enabled === true;
    showMorphToast(`우선순위 모드를 바꾸지 못했습니다: ${error.message}`);
  }
}

function displayPriorityModel(modelId) {
  const names = {
    'gpt-6-luna': 'GPT-6 Luna',
    'gpt-6-sol': 'GPT-6 Sol',
    'gpt-6-astra': 'GPT-6 Astra',
    'gpt-6.1-sol': 'GPT-6.1 Sol',
    'gpt-6.1-terra': 'GPT-6.1 Terra',
    'gpt-5.6-sol': 'GPT-5.6 Sol',
    'gpt-5.6-terra': 'GPT-5.6 Terra',
    'gpt-5.6-luna': 'GPT-5.6 Luna',
    'gemini-3.8-flash-medium': 'Gemini 3.8 Flash Medium'
  };
  return names[String(modelId || '').toLowerCase()] || String(modelId || '모델 미지정');
}

function renderActiveModelSelection() {
  const selectedModel = selectedModelId === 'auto'
    ? (activeTier ? `자동 · ${displayPriorityModel(activeTier.model)}${String(activeTier.model).toLowerCase() === 'gpt-6-luna' && selectedReasoningEffort === 'low' ? ' + Light' : ''}` : '자동 · 모델 확인 중')
    : selectedModelId === 'gpt-6-luna' && selectedReasoningEffort === 'low'
      ? 'GPT-6 Luna + Light'
      : displayPriorityModel(selectedModelId);
  if (!activeTier) {
    const noActiveRoute = '사용 가능한 실행 계정 없음';
    if (activeModelLabel) activeModelLabel.textContent = selectedModel;
    if (activeModelAccount) activeModelAccount.textContent = noActiveRoute;
    const prioritySelectedModel = document.getElementById('prioritySelectedModel');
    const priorityActualRoute = document.getElementById('priorityActualRoute');
    if (prioritySelectedModel) prioritySelectedModel.textContent = selectedModel;
    if (priorityActualRoute) priorityActualRoute.textContent = noActiveRoute;
    if (modelPillTrigger) {
      modelPillTrigger.title = `선택 모델: ${selectedModel} · ${noActiveRoute}`;
      modelPillTrigger.setAttribute('aria-label', `선택 모델 ${selectedModel}; ${noActiveRoute}`);
    }
    if (effortPopupModel) effortPopupModel.textContent = selectedModel;
    const modelCaption = document.querySelector('.model-pill-caption');
    if (modelCaption) modelCaption.textContent = selectedModelId === 'auto' ? '자동 우선순위 · 현재 모델' : '현재 선택 모델';
    document.querySelectorAll('.model-option').forEach(option => {
      const selected = option.dataset.model === selectedModelId;
      option.classList.toggle('selected', selected);
      option.setAttribute('aria-selected', String(selected));
    });
    return;
  }
  const actualModel = displayPriorityModel(activeTier.model);
  const modelCaption = document.querySelector('.model-pill-caption');
  if (modelCaption) modelCaption.textContent = selectedModelId === 'auto' ? '자동 우선순위 · 실제 모델' : '현재 선택 모델';
  const account = activeTier.email || activeTier.account || '계정 정보 없음';
  if (activeModelLabel) activeModelLabel.textContent = selectedModel;
  const isCodex = String(activeTier.provider || '').toLowerCase().includes('codex');
  const tierIdentity = /secondary/i.test(`${activeTier.id} ${activeTier.name}`) ? '보조 계정' : /primary/i.test(`${activeTier.id} ${activeTier.name}`) ? '주 계정' : '계정';
  const routeIdentity = isCodex ? `Codex ${tierIdentity}` : String(activeTier.name || activeTier.provider || '계정');
  const routeReady = activeTier.providerReady?.connected === true;
  const routeState = isCodex ? (routeReady ? '연결됨' : activeTier.providerReady?.message || '로그인 필요') : '연결됨';
  if (activeModelAccount) activeModelAccount.textContent = `실제 요청 계정: ${activeTier.tier || '-'}순위 · ${routeIdentity} · ${account} · ${routeState}`;
  const prioritySelectedModel = document.getElementById('prioritySelectedModel');
  const priorityActualRoute = document.getElementById('priorityActualRoute');
  if (prioritySelectedModel) prioritySelectedModel.textContent = selectedModel;
  if (priorityActualRoute) {
    const connection = isCodex ? (routeReady ? '실행 연결됨' : '로그인 필요') : '실행 경로 연결됨';
    const rank = Number(activeTier.tier) || 0;
    priorityActualRoute.innerHTML = `
      <span class="priority-current-route-label">실제 다음 요청에 사용할 경로</span>
      <span class="priority-route-model">${escapeHtml(actualModel)}</span>
      <span class="priority-route-rank rank-tier-${rank}">${rank || '-'}순위 · ${escapeHtml(routeIdentity)} · 현재 선택/라우팅</span>
      <span class="priority-route-account"><small>이번 요청 계정</small><strong>${escapeHtml(account)}</strong></span>
      <span class="priority-route-state ${routeReady || !isCodex ? 'connected' : 'disconnected'}">${escapeHtml(connection)}</span>
    `;
  }
  if (modelPillTrigger) {
    modelPillTrigger.title = `현재 선택 모델: ${selectedModel} · 실제 요청 대상: ${actualModel}, ${activeTier.tier || '-'}순위 ${routeIdentity}, ${account} · ${routeState}`;
    modelPillTrigger.setAttribute('aria-label', `현재 선택 모델 ${selectedModel}; 실제 다음 요청 ${actualModel}; ${activeTier.tier || '-'}순위 ${routeIdentity}; 계정 ${account}; ${routeState}`);
  }
  if (effortPopupModel) effortPopupModel.textContent = selectedModel;
  document.querySelectorAll('.model-option').forEach(option => {
    const selected = option.dataset.model === selectedModelId;
    option.classList.toggle('selected', selected);
    option.setAttribute('aria-selected', String(selected));
  });
}

function tierQuotaLabel(tier) {
  const health = tier?.health;
  const remaining = health?.totalRemainingPercent;
  if (health?.quotaState === 'limit-detected') return '한도 초과 응답 감지 · 잔여량 미확인';
  if (health?.quotaState === 'limit-reported') return '사용 한도 소진 보고 · 잔여량 미확인';
  if (health?.quotaState === 'below-threshold' && Number.isFinite(remaining)) {
    const reset = health.nextResetAt ? new Date(health.nextResetAt).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '기한 미확인';
    return `한도 ${Math.round(remaining)}% · 갱신 예정 ${reset}`;
  }
  if (health?.isThrottled) return '실행 불가 · 일시 제외';
  if (Number.isFinite(remaining)) return `한도 확인 · ${Math.round(remaining)}% 남음`;
  return '한도 수치 미확인';
}

function tierConnectionLabel(tier) {
  const provider = tier?.providerReady;
  if (provider) return provider.connected ? '계정 연결됨' : provider.available ? '로그인 필요' : '실행 경로 사용 불가';
  return '계정 연결 상태 미확인';
}

function tierQuotaCheckedLabel(tier) {
  const timestamp = tier?.health?.lastQuotaRefreshAt;
  if (tier?.health?.quotaRefreshError) {
    const attempted = Number.isFinite(tier.health.lastQuotaRefreshAttemptAt)
      ? new Date(tier.health.lastQuotaRefreshAttemptAt).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })
      : '';
    return `최근 한도 조회 실패${attempted ? ` · 시도 ${attempted}` : ''} · 기존 상태 유지`;
  }
  return Number.isFinite(timestamp)
    ? `최근 실시간 조회 · ${new Date(timestamp).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}`
    : '';
}

function tierStatusDetail(tier) {
  const providerMessage = tier?.providerReady?.message;
  if (providerMessage) return providerMessage;
  const health = tier?.health;
  const remaining = health?.totalRemainingPercent;
  if (Number.isFinite(remaining)) {
    const fiveHour = Number(health?.fiveHourRemainingPercent);
    const quota = Number.isFinite(fiveHour) ? ` · 5시간 한도 ${Math.round(fiveHour)}% 남음` : '';
    return `${tier?.model || ''}${quota}`;
  }
  return tier?.model || '연결 상태 정보를 받지 못했습니다.';
}

function renderDrawerTiers() {
  if (!priorityStatus || !priorityStatus.tiers) return;
  drawerTierList.innerHTML = '';

  const codexAccountsByModel = new Map();
  for (const tier of priorityStatus.tiers) {
    if (!String(tier.provider || '').toLowerCase().includes('codex')) continue;
    const model = String(tier.model || '').toLowerCase();
    if (!model) continue;
    const accounts = codexAccountsByModel.get(model) || [];
    accounts.push(tier);
    codexAccountsByModel.set(model, accounts);
  }
  for (const [model, accounts] of codexAccountsByModel) {
    const distinctAccounts = accounts.filter((tier, index) => accounts.findIndex(other =>
      `${String(other.email || '').toLowerCase()}|${String(other.account || other.id || '').toLowerCase()}`
      === `${String(tier.email || '').toLowerCase()}|${String(tier.account || tier.id || '').toLowerCase()}`
    ) === index);
    if (distinctAccounts.length < 2) continue;

    const comparison = document.createElement('section');
    comparison.className = 'priority-account-pair';
    comparison.setAttribute('aria-label', `${displayPriorityModel(model)}를 사용하는 별도 Codex 계정 비교`);
    comparison.innerHTML = `
      <strong class="priority-account-pair-title">같은 모델 · 다른 Codex 계정</strong>
      <span class="priority-account-pair-note">두 계정 모두 ${escapeHtml(displayPriorityModel(model))}를 사용하지만 로그인과 연결 상태는 각각 다릅니다.</span>
      <div class="priority-account-pair-list">
        ${distinctAccounts.sort((a, b) => a.tier - b.tier).map(tier => {
          const tierIdentity = /secondary/i.test(`${tier.id} ${tier.name}`) ? '보조 계정' : /primary/i.test(`${tier.id} ${tier.name}`) ? '주 계정' : '계정';
          const isActive = tier.id === activeTier?.id;
          const rankLabel = tier.tier === 2 ? '2순위 · Codex 보조 계정' : tier.tier === 3 ? '3순위 · Codex 주 계정' : `${tier.tier}순위 · Codex ${tierIdentity}`;
          return `<div class="priority-account-pair-row tier-${escapeHtml(tier.tier)} ${isActive ? 'active' : ''}" aria-label="${escapeHtml(rankLabel)} · ${escapeHtml(tier.email || '이메일 정보 없음')} · 계정 ID ${escapeHtml(tier.account || tier.id || 'ID 정보 없음')} · ${isActive ? '현재 선택/라우팅' : '폴백'}">
            <span class="priority-account-pair-rank"><strong>${escapeHtml(tier.tier)}순위</strong><small>${isActive ? '현재 라우팅' : '폴백 계정'}</small></span>
            <span class="priority-account-pair-identity"><strong>${escapeHtml(rankLabel)} · ${escapeHtml(displayPriorityModel(tier.model))}</strong><span>로그인 이메일 · ${escapeHtml(tier.email || '이메일 정보 없음')}</span><span>계정 ID · ${escapeHtml(tier.account || tier.id || 'ID 정보 없음')}</span></span>
            <span class="priority-account-pair-state ${isActive ? 'active' : ''}">${isActive ? '현재 선택/라우팅' : `${tier.tier}순위 · 폴백`}</span>
          </div>`;
        }).join('')}
      </div>
    `;
    drawerTierList.appendChild(comparison);
  }

  for (const tier of priorityStatus.tiers) {
    const isActive = tier.id === activeTier?.id;
    const isCodex = String(tier.provider || '').toLowerCase().includes('codex');
    const tierIdentity = /secondary/i.test(`${tier.id} ${tier.name}`) ? '보조 계정' : /primary/i.test(`${tier.id} ${tier.name}`) ? '주 계정' : '계정';
    const readiness = tier.providerReady;
    const accountEmail = tier.email || '이메일 정보 없음';
    const accountId = tier.account || tier.id || 'ID 정보 없음';
    const card = document.createElement('div');
    if (fantasyWarriorMode) {
      const warrior = fantasyWarriorProfile(tier);
      const readiness = tier.providerReady;
      const health = tier.health || {};
      const remaining = Number(health.totalRemainingPercent);
      const hasKnownQuota = Number.isFinite(remaining);
      const depleted = health.isThrottled || (hasKnownQuota && remaining <= 10);
      const connected = readiness ? readiness.connected === true : true;
      const selectable = tier.enabled !== false && connected && !depleted;
      const hp = hasKnownQuota ? Math.max(0, Math.min(100, remaining)) : depleted ? 0 : null;
      const nextReset = health.nextResetAt
        ? new Date(health.nextResetAt).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })
        : null;
      const state = tier.enabled === false ? '명단에서 비활성'
        : !connected ? '잠김 · 계정 연결 필요'
          : depleted ? `${health.quotaState === 'provider-unavailable' ? '상태 회복 대기' : '회복 대기'}${hasKnownQuota ? ` · 체력 ${Math.round(hp)}%` : ' · 한도 재확인 필요'}${nextReset ? ` · ${nextReset} 갱신` : ''}`
            : hasKnownQuota ? `출전 가능 · 체력 ${Math.round(hp)}%`
              : '출전 가능 · 한도 수치 미확인';
      card.className = `tier-list-card priority-account-card fantasy-warrior-card ${isActive ? 'active' : ''} ${selectable ? 'selectable' : 'unavailable'} ${isCodex ? 'codex-account' : 'google-account'} tier-${tier.tier}`;
      card.innerHTML = `
        <div class="fantasy-warrior-topline">
          <span class="priority-account-rank">${escapeHtml(tier.tier)}순위</span>
          <span class="fantasy-warrior-class">${escapeHtml(warrior.role)}</span>
          ${isActive ? `<span class="priority-account-active">${priorityStatus?.enabled === false ? '직접 선택됨' : '현재 출전 중'}</span>` : ''}
        </div>
        <div class="fantasy-warrior-identity">
          <div class="fantasy-warrior-avatar" aria-hidden="true">${warrior.icon}</div>
          <div class="fantasy-warrior-copy">
            <strong>${escapeHtml(isCodex ? tierIdentity : tier.name || tier.provider || warrior.role)}</strong>
            <span>${escapeHtml(displayPriorityModel(tier.model))} · ${escapeHtml(accountEmail)}</span>
          </div>
        </div>
        <div class="fantasy-warrior-health" role="img" aria-label="${escapeHtml(state)}">
          <div class="fantasy-warrior-health-track"><span style="width:${hp === null ? 0 : hp}%"></span></div>
          <strong>${escapeHtml(state)}</strong>
        </div>
        <div class="priority-account-id">길드 계정 · ${escapeHtml(accountId)}</div>
      `;
      const select = document.createElement('button');
      select.type = 'button';
      select.className = 'fantasy-warrior-select';
      select.textContent = isActive && priorityStatus?.enabled === false ? '선택 완료 · 수동 고정' : '전사 선택';
      select.disabled = !selectable || (isActive && priorityStatus?.enabled === false);
      select.setAttribute('aria-label', `${warrior.role} ${selectable ? '선택 가능' : state}`);
      select.addEventListener('click', () => switchTier(tier.id));
      card.appendChild(select);
      drawerTierList.appendChild(card);
      continue;
    }
    card.className = `tier-list-card priority-account-card ${isActive ? 'active' : ''} ${isCodex ? 'codex-account' : 'google-account'} tier-${tier.tier}`;
    const explicitRankLabel = tier.tier === 2 ? '2순위 · Codex 보조 계정' : tier.tier === 3 ? '3순위 · Codex 주 계정' : `${tier.tier}순위 계정`;
    card.setAttribute('aria-label', `${explicitRankLabel} · ${tier.email || '이메일 정보 없음'} · 계정 ID ${tier.account || tier.id || 'ID 정보 없음'} · ${isActive ? '현재 선택/라우팅' : '폴백'}`);
    card.innerHTML = `
      <div class="priority-account-heading">
        <span class="priority-account-rank">${escapeHtml(explicitRankLabel)}</span>
        <span class="priority-account-provider">${isCodex ? 'OpenAI Codex' : escapeHtml(tier.name || tier.provider || '계정')}</span>
        <span class="priority-account-active ${isActive ? '' : 'fallback'}">${isActive ? (priorityStatus?.enabled === false ? '현재 선택 · 수동 라우팅' : '현재 선택 · 자동 라우팅') : '폴백 계정'}</span>
      </div>
      <div class="priority-account-model"><span>${isActive ? '다음 요청 모델' : '이 계정의 모델'}</span><strong>${escapeHtml(displayPriorityModel(tier.model))}</strong></div>
      <div class="priority-account-identity"><div class="priority-account-email"><span>로그인 이메일</span><strong>${escapeHtml(accountEmail)}</strong></div><div class="priority-account-id"><span>계정 ID</span><strong>${escapeHtml(accountId)}</strong></div></div>
      <div class="priority-account-ready ${readiness && !readiness.connected ? 'not-ready' : ''}">${escapeHtml(tierConnectionLabel(tier))}</div>
      <div class="priority-account-quota">${escapeHtml(tierQuotaLabel(tier))}</div>
      ${tierQuotaCheckedLabel(tier) ? `<div class="priority-account-quota">${escapeHtml(tierQuotaCheckedLabel(tier))}</div>` : ''}
    `;

    drawerTierList.appendChild(card);
  }
}

function fantasyWarriorProfile(tier) {
  const identity = `${tier?.id || ''} ${tier?.name || ''}`.toLowerCase();
  const provider = String(tier?.provider || '').toLowerCase();
  if (provider.includes('antigravity') || provider === 'google') return { role: '별빛 마도사', icon: '🧙' };
  if (identity.includes('secondary')) return { role: '그림자 검사', icon: '⚔️' };
  if (identity.includes('primary')) return { role: '수호 기사', icon: '🛡️' };
  const roles = [
    { role: '왕국 수호자', icon: '🛡️' },
    { role: '황혼의 검사', icon: '⚔️' },
    { role: '룬 마도사', icon: '🧙' }
  ];
  return roles[(Math.max(1, Number(tier?.tier) || 1) - 1) % roles.length];
}

async function switchTier(tierId) {
  try {
    const res = await fetch('/api/priority/switch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tierId })
    });
    const result = await res.json();
    if (!res.ok || !result.ok) throw new Error(result.error || `계정 전환 실패 (${res.status})`);
    priorityStatus = result.status;
    activeTier = result.status?.activeTier || result.tier;
    renderPriorityMode();
    renderActiveModelSelection();
    renderDrawerTiers();
    showMorphToast(`수동 계정 선택 · ${activeTier?.email || activeTier?.name || tierId}`);
  } catch (err) {
    alert('티어 전환 실패: ' + err.message);
  }
}

// ============================================================================
// Reference 3: Microphone Voice Dictation
// ============================================================================

function toggleSpeechInput() {
  const nativeSpeech = window.webkit?.messageHandlers?.speech;
  if (isRecording) {
    stopRecording();
    return;
  }

  if (nativeSpeech) {
    btnMicrophone.title = '음성 인식 권한을 확인하는 중...';
    nativeSpeech.postMessage('start');
    return;
  }

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (SpeechRecognition) {
    try {
      const recognition = new SpeechRecognition();
      speechRecognition = recognition;
      recognition.lang = 'ko-KR';
      recognition.interimResults = true;

      recognition.onstart = () => {
        setSpeechRecording(true);
      };

      recognition.onresult = event => {
        const transcript = Array.from(event.results)
          .map(result => result[0].transcript)
          .join('');
        composerInput.value = transcript;
        composerInput.dispatchEvent(new Event('input'));
      };

      recognition.onerror = event => {
        setSpeechRecording(false);
        showMorphToast(`음성 인식 실패: ${event.error || '다시 시도해 주세요.'}`);
      };
      recognition.onend = () => {
        speechRecognition = null;
        setSpeechRecording(false);
      };
      recognition.start();
      return;
    } catch (error) {
      speechRecognition = null;
      showMorphToast(`음성 인식을 시작하지 못했습니다: ${error.message}`);
      return;
    }
  }

  showMorphToast('이 앱 런타임은 음성 인식을 지원하지 않습니다.');
}

function stopRecording() {
  const recognition = speechRecognition;
  speechRecognition = null;
  if (recognition) {
    try { recognition.stop(); } catch (_) {}
  }
  if (window.webkit?.messageHandlers?.speech) {
    window.webkit.messageHandlers.speech.postMessage('stop');
  }
  setSpeechRecording(false);
}

function setSpeechRecording(recording) {
  isRecording = recording;
  btnMicrophone.classList.toggle('recording', recording);
  btnMicrophone.title = recording ? '듣고 있습니다... 클릭 시 중단' : '음성 받아쓰기 / 오디오 명령';
  if (!recording) composerInput.placeholder = 'Work with Only Chat...';
}

window.onlyChatSpeechState = recording => setSpeechRecording(Boolean(recording));
window.onlyChatSpeechResult = text => {
  composerInput.value = text;
  composerInput.dispatchEvent(new Event('input'));
};
window.onlyChatSpeechError = message => {
  setSpeechRecording(false);
  showMorphToast(message);
};

// ============================================================================
// Turn Execution & Streaming (With Reference 3 Stop / Send Button)
// ============================================================================

async function refreshAdminManagerStatus() {
  if (!managerModeToggle) return;
  const label = document.getElementById('managerModeLabel');
  managerModeToggle.disabled = true;
  try {
    const response = await fetch('/api/admin-manager/status');
    if (!response.ok) throw new Error('backend unavailable');
    const status = await response.json();
    const manager = status.modules?.find(module => module.id === 'admin-manager');
    const coreModules = ['agent-engine', 'tool-registry'];
    const staleCore = status.modules?.filter(module => coreModules.includes(module.id) && module.state !== 'loaded') || [];
    if (status.apiVersion !== 1 || manager?.state !== 'loaded' || !status.capabilities?.length) {
      throw new Error('capability registry unavailable');
    }
    if (staleCore.length) {
      managerModeToggle.checked = false;
      managerModeToggle.disabled = true;
      managerModeToggle.title = `Only Chat 서버를 새로고침해야 합니다: ${staleCore.map(module => module.id).join(', ')}`;
      if (label) label.textContent = '관리자 AI · 서버 업데이트 필요';
      return;
    }
    const availableCount = status.capabilities.filter(capability => ['executable', 'settings-only'].includes(capability.state)).length;
    if (!availableCount) throw new Error('no actionable capabilities');
    managerModeToggle.disabled = false;
    managerModeToggle.title = `사용 가능한 Mac 기능 ${availableCount}/${status.capabilities.length}개를 참조합니다. 이 모드는 도구를 실행하지 않습니다.`;
    if (label) label.textContent = `관리자 AI · 제안 전용 (${availableCount}/${status.capabilities.length})`;
  } catch (_) {
    managerModeToggle.checked = false;
    managerModeToggle.title = 'Manager 백엔드를 사용할 수 없습니다. Only Chat 서버 업데이트 후 다시 확인하세요.';
    if (label) label.textContent = '관리자 AI · 서버 업데이트 필요';
  }
}

async function handleSend() {
  const prompt = composerInput.value.trim();
  if (!prompt || isGenerating) return;

  // Clear input & reset height
  composerInput.value = '';
  composerInput.style.height = 'auto';

  if (emptyState) emptyState.style.display = 'none';

  // Set generating state & update Orange Button (Ref 3)
  setGeneratingState(true);

  // Update Titlebar
  titlebarThreadTitle.textContent = prompt.length > 35 ? prompt.slice(0, 35) + '...' : prompt;

  // Append User message
  appendUserMessage(prompt);

  // Create Assistant Message container (Warm Peach Card - Ref 1 & 2)
  const assistantCard = createAssistantContainer({ timing: true });
  timeline.appendChild(assistantCard.row);
  const assistantTimer = startAssistantTimer(assistantCard);
  timeline.scrollTop = timeline.scrollHeight;

  const sessionStorageMatch = prompt.trim().match(/^\/session-storage(?:\s+(\d{1,2}))?$/);
  if (sessionStorageMatch) {
    try {
      const days = Math.max(1, Math.min(90, Number(sessionStorageMatch[1]) || 7));
      const response = await fetch(`/api/sessions/storage-report?days=${days}`, { cache: 'no-store' });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.error || `세션 저장량 조회 실패 (${response.status})`);
      const gib = bytes => `${(Number(bytes || 0) / (1024 ** 3)).toFixed(4)} GiB`;
      const report = document.createElement('pre');
      report.className = 'text-body';
      report.style.whiteSpace = 'pre-wrap';
      report.textContent = [
        `Only Chat 내부 대화 기록 · ${payload.windowDays}일 분석`,
        `현재 기록 ${gib(payload.totalBytes)} · ${payload.totalRecords}개 항목`,
        `최근 ${payload.windowDays}일에 추가된 기록 ${gib(payload.recentBytes)} · ${payload.recentRecords}개 항목`,
        `추적 경로: ${payload.storageDir}`,
        '기록 종류별 현재 용량 (최근 기간 추가량)',
        ...(payload.byRecordType || []).map(item => `  ${item.type}: ${gib(item.bytes)} (${item.records}개) · 최근 ${gib(item.recentBytes)}`),
        '큰 대화 기록 상위 10개 (기록 종류별 상세)',
        ...(payload.largestSessions || []).map(item => `  ${item.title} [${item.sessionId}]: ${gib(item.bytes)} · 최근 ${gib(item.recentBytes)}\n${item.types.map(type => `    ${type.type}: ${gib(type.bytes)} (${type.records}개) · 최근 ${gib(type.recentBytes)}`).join('\n')}`),
        payload.incomplete ? `일부 기록은 손상 또는 4MiB 초과라 증가 날짜/종류 귀속이 일부 미완전합니다` : '기록 분석 완료',
        payload.unattributedBytes ? `기록 종류에 귀속되지 않은 바이트 ${gib(payload.unattributedBytes)} · 손상/비표준 줄을 확인하세요` : '종류 미확인 바이트: 없음',
        payload.malformedBytes ? `분석할 수 없는 JSON 줄: ${gib(payload.malformedBytes)}` : '손상된 JSON 기록 줄: 없음',
        `측정: ${new Date(payload.measuredAt).toLocaleString()} · 내부 JSONL만 포함; Codex 외부 대화/기타 앱 파일 제외`
      ].join('\n');
      assistantCard.content.appendChild(report);
    } catch (err) {
      const message = document.createElement('div');
      message.className = 'text-body';
      message.textContent = `Only Chat 세션 저장량 조회 오류: ${err.message}`;
      assistantCard.content.appendChild(message);
    } finally {
      assistantTimer.finish();
      finishAssistantWork(assistantCard, assistantCard.workOutcome || 'complete');
      setGeneratingState(false);
      applyPendingUiMorphReloadWhenSafe();
    }
    return;
  }

  if (prompt.trim() === '/capacity') {
    try {
      const response = await fetch('/api/spacekeeper/capacity', { cache: 'no-store' });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.error || `용량 조회 실패 (${response.status})`);
      const report = document.createElement('div');
      report.className = 'text-body';
      const reserveGiB = Number(payload.reserveGiB) || 20;
      report.textContent = `Space Keeper · ${payload.severity || 'unknown'}\n현재 여유 공간 ${Number(payload.freeGiB).toFixed(2)} GiB · 보호 여유 ${reserveGiB} GiB\n${Array.isArray(payload.issues) && payload.issues.length ? payload.issues.join('\n') : '저장공간 가드에서 확인된 문제가 없습니다.'}\n확인 시각 ${new Date().toLocaleTimeString()}`;
      assistantCard.content.appendChild(report);
    } catch (err) {
      const message = document.createElement('div');
      message.className = 'text-body';
      message.textContent = `Space Keeper 용량 조회 오류: ${err.message}`;
      assistantCard.content.appendChild(message);
    } finally {
      assistantTimer.finish();
      finishAssistantWork(assistantCard, assistantCard.workOutcome || 'complete');
      setGeneratingState(false);
      applyPendingUiMorphReloadWhenSafe();
    }
    return;
  }

  if (prompt.startsWith('/spacekeeper')) {
    try {
      const match = prompt.match(/^\/spacekeeper\s+([A-Za-z0-9][A-Za-z0-9._-]{0,127})$/);
      if (!match) throw new Error('사용법: /spacekeeper task-key');
      const response = await fetch('/api/spacekeeper/session-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskKey: match[1] })
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.error || `보고서 조회 실패 (${response.status})`);
      const report = document.createElement('pre');
      report.className = 'text-body';
      report.style.whiteSpace = 'pre-wrap';
      report.textContent = JSON.stringify(payload, null, 2);
      assistantCard.content.appendChild(report);
    } catch (err) {
      const message = document.createElement('div');
      message.className = 'text-body';
      message.textContent = `Space Keeper 보고서 오류: ${err.message}`;
      assistantCard.content.appendChild(message);
    } finally {
      assistantTimer.finish();
      setGeneratingState(false);
      applyPendingUiMorphReloadWhenSafe();
    }
    return;
  }

  currentAbortController = new AbortController();
  activeAssistantCard = assistantCard;

  try {
    const res = await fetch('/api/turn', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sessionId: currentSessionId,
        prompt,
        reasoningEffort: selectedReasoningEffort,
        overrideTierId: activeTier?.id,
        managerMode: managerModeToggle?.checked === true,
        sandboxPolicy: 'workspace-write'
      }),
      signal: currentAbortController.signal
    });
    if (!res.ok) {
      const error = await res.json().catch(() => ({}));
      throw new Error(error.error || `요청 실패 (${res.status})`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const lines = buffer.split('\n');
      buffer = lines.pop();

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        const jsonStr = line.replace('data: ', '').trim();
        if (jsonStr === '[DONE]') break;

        try {
          const event = JSON.parse(jsonStr);
          handleStreamEvent(event, assistantCard);
        } catch (_) {}
      }
    }

    await refreshPriorityStatus();
    await loadSessions();

  } catch (err) {
    assistantCard.workOutcome = err.name === 'AbortError' ? 'aborted' : 'error';
    appendTurnNotice(assistantCard, err.name === 'AbortError'
      ? '⏹ 사용자에 의해 작업이 중단되었습니다.'
      : `❌ 요청 실패: ${err.message}`, err.name === 'AbortError' ? 'warning' : 'error');
  } finally {
    activeAssistantCard = null;
    finishAssistantMessage(assistantCard);
    assistantTimer.finish();
    finishAssistantWork(assistantCard, assistantCard.workOutcome || 'complete');
    setGeneratingState(false);
    applyPendingUiMorphReloadWhenSafe();
  }
}

function abortActiveTurn() {
  if (currentAbortController) {
    currentAbortController.abort();
    currentAbortController = null;
  }
  setGeneratingState(false);
  applyPendingUiMorphReloadWhenSafe();
}

function setGeneratingState(generating) {
  isGenerating = generating;
  const iconSend = btnSend.querySelector('.icon-send');
  const iconStop = btnSend.querySelector('.icon-stop');

  if (generating) {
    iconSend.style.display = 'none';
    iconStop.style.display = 'block';
    btnSend.title = '작업 중단 (Stop)';
  } else {
    iconSend.style.display = 'block';
    iconStop.style.display = 'none';
    btnSend.title = '채팅 전송 (Send)';
  }
}

function appendUserMessage(text) {
  const row = document.createElement('div');
  row.className = 'message-row user';
  row.innerHTML = `
    <div class="bubble">${escapeHtml(text)}</div>
  `;
  timeline.appendChild(row);
  timeline.scrollTop = timeline.scrollHeight;
}

// Assistant Peach Card (Ref 1)
function createAssistantContainer(options = {}) {
  const row = document.createElement('div');
  row.className = 'message-row assistant';

  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  bubble.innerHTML = `
    ${options.timing ? '<details class="assistant-work-details assistant-turn-progress" open><summary class="assistant-work-summary"><span class="assistant-turn-meta" role="timer" aria-label="응답 경과 시간" aria-live="off">작업 중 · 0초</span><span class="assistant-work-summary-label">요청 준비 중</span></summary><div class="assistant-work-panel"><div class="assistant-work-status" role="status" aria-live="polite">요청을 분석하고 있습니다…</div><div class="assistant-work-steps"></div></div></details>' : ''}
    <div class="assistant-content"></div>
    <div class="assistant-actions-bar">
      <button class="show-more-btn" onclick="toggleAssistantMore(this)">Show more <span>⌄</span></button>
      <button class="copy-btn" title="복사" onclick="copyAssistantText(this)">
        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
      </button>
    </div>
  `;

  row.appendChild(bubble);
  return {
    row,
    bubble,
    content: bubble.querySelector('.assistant-content'),
    timerNode: bubble.querySelector('.assistant-turn-meta'),
    workStatusNode: bubble.querySelector('.assistant-work-status'),
    workDetails: bubble.querySelector('.assistant-work-details'),
    workSummaryNode: bubble.querySelector('.assistant-work-summary'),
    workSummaryLabelNode: bubble.querySelector('.assistant-work-summary-label'),
    workStepsNode: bubble.querySelector('.assistant-work-steps'),
    workStepCount: 0,
    currentWorkStep: null,
    workOutcome: 'complete',
    messageNode: null,
    messageText: ''
  };
}

function startAssistantTimer(card) {
  const startedAt = performance.now();
  let intervalId = null;
  const elapsed = () => window.OnlyChatPresentation?.formatElapsed
    ? window.OnlyChatPresentation.formatElapsed(performance.now() - startedAt)
    : `${Math.max(0, Math.ceil((performance.now() - startedAt) / 1000))}초`;
  const update = () => {
    if (card.timerNode) card.timerNode.textContent = `작업 중 · ${elapsed()}`;
  };
  update();
  if (card.timerNode) intervalId = window.setInterval(update, 1000);
  let finished = false;
  return {
    finish() {
      if (finished) return;
      finished = true;
      if (intervalId !== null) window.clearInterval(intervalId);
      if (card.timerNode) {
        card.timerNode.textContent = `작업 시간 · ${elapsed()}`;
        card.timerNode.dataset.state = 'complete';
        card.timerNode.setAttribute('aria-label', `응답 완료, 작업 시간 ${card.timerNode.textContent.replace('작업 시간 · ', '')}`);
        card.timerNode.setAttribute('aria-live', 'polite');
      }
    }
  };
}

function finishAssistantMessage(card) {
  if (!card?.messageNode) return;
  if (!window.OnlyChatPresentation?.renderMarkdown) {
    card.messageNode.textContent = card.messageText;
    card.messageNode.classList.add('assistant-answer');
    return;
  }
  card.messageNode.innerHTML = window.OnlyChatPresentation.renderMarkdown(card.messageText);
  card.messageNode.classList.add('assistant-answer');
}

function appendTurnNotice(card, text, kind) {
  const notice = document.createElement('div');
  notice.className = `assistant-turn-notice ${kind || ''}`;
  notice.textContent = text;
  card.content.appendChild(notice);
}

function setAssistantWorkStatus(card, text) {
  if (card?.workStatusNode && text) card.workStatusNode.textContent = text;
}

function ensureAssistantWorkDetails(card) {
  if (card.workDetails) return card.workDetails;
  const details = document.createElement('details');
  details.className = 'assistant-work-details';
  details.open = true;
  const summary = document.createElement('summary');
  summary.className = 'assistant-work-summary';
  summary.textContent = '작업 과정 · 0단계 · 진행 중';
  const steps = document.createElement('div');
  steps.className = 'assistant-work-steps';
  details.appendChild(summary);
  details.appendChild(steps);
  card.content.insertBefore(details, card.content.firstChild);
  card.workDetails = details;
  card.workSummaryNode = summary;
  card.workSummaryLabelNode = null;
  card.workStepsNode = steps;
  return details;
}

function setAssistantWorkSummary(card, text) {
  if (card?.workSummaryLabelNode) card.workSummaryLabelNode.textContent = text;
  else if (card?.workSummaryNode) card.workSummaryNode.textContent = text;
}

function toolDisplayName(name) {
  const labels = {
    exec_command: '명령 실행', file_change: '파일 변경', read_file: '파일 읽기',
    list_files: '파일 목록 확인', search_files: '코드 검색', browser_open: '브라우저 열기',
    browser_read: '브라우저 내용 읽기', browser_act: '브라우저 조작'
  };
  return labels[name] || String(name || '도구 실행');
}

function finishAssistantWork(card, outcome = 'complete') {
  if (!card) return;
  const labels = { complete: '완료', error: '오류', aborted: '중단' };
  const label = labels[outcome] || labels.complete;
  if (card.workSummaryNode) {
    setAssistantWorkSummary(card, `작업 과정 · ${card.workStepCount}단계 · ${label}`);
    card.workDetails.open = false;
  }
  setAssistantWorkStatus(card, outcome === 'complete' ? '응답 완료' : outcome === 'aborted' ? '작업이 중단되었습니다' : '작업 중 오류가 발생했습니다');
}

function handleStreamEvent(event, card) {
  switch (event.type) {
    case 'tier_resolved': {
      activeTier = event.tier || null;
      setAssistantWorkStatus(card, '실행 계정을 확인하고 있습니다…');
      renderActiveModelSelection();
      void refreshPriorityStatus();
      break;
    }
    case 'error': {
      card.workOutcome = 'error';
      setAssistantWorkStatus(card, '응답을 완료하지 못했습니다');
      const failure = document.createElement('div');
      failure.className = 'text-body';
      const categories = {
        quota_rate_limit: '사용 한도 또는 요청 속도 제한',
        authentication: '계정 인증 필요',
        model_unavailable: '모델을 사용할 수 없음',
        sandbox_permission_blocked: '샌드박스 또는 권한 차단',
        network_unavailable: '네트워크 연결 불가',
        provider_failure: '제공자 오류'
      };
      const category = categories[event.category];
      const model = typeof event.model === 'string' && /^[A-Za-z0-9._+:/ -]{1,80}$/.test(event.model) ? event.model : '';
      const rank = Number.isSafeInteger(event.rank) && event.rank > 0 ? event.rank : null;
      const attempt = [rank ? `시도한 순위: ${rank}순위` : '', model ? `시도한 모델: ${model}` : ''].filter(Boolean).join(' · ');
      const detail = category ? `실패 유형: ${category}${attempt ? ` · ${attempt}` : ''}` : (event.message || '서버에서 오류 사유를 전달하지 않았습니다.');
      failure.textContent = `❌ AI 응답을 받지 못했습니다.\n${detail}\n응답이 없었으므로 작업이 완료된 것으로 간주하지 마세요.`;
      card.content.appendChild(failure);
      timeline.scrollTop = timeline.scrollHeight;
      break;
    }

    case 'reasoning_delta': {
      // Keep private model reasoning out of the transcript; show only a user-facing stage.
      setAssistantWorkStatus(card, '요청을 분석하고 있습니다…');
      break;
    }

    case 'message_delta': {
      setAssistantWorkStatus(card, '응답을 작성하고 있습니다…');
      let msg = card.content.querySelector('.text-body');
      if (!msg) {
        msg = document.createElement('div');
        msg.className = 'text-body';
        card.content.appendChild(msg);
      }
      if (!card.messageNode) {
        card.messageNode = document.createElement('div');
        card.messageNode.style.cssText = 'margin-top: 4px; white-space: pre-wrap;';
        msg.appendChild(card.messageNode);
      }
      card.messageText += String(event.delta || '');
      card.messageNode.textContent = card.messageText;
      timeline.scrollTop = timeline.scrollHeight;
      break;
    }

    case 'tool_start': {
      const details = ensureAssistantWorkDetails(card);
      const call = event.call || {};
      const args = call.args || {};
      const detail = call.name === 'exec_command' ? String(args.command || '')
        : call.name === 'file_change' ? `${args.change || 'updated'} · ${args.path || ''}` : '';
      const step = document.createElement('div');
      step.className = 'assistant-work-step';
      if (call.id) step.dataset.toolCallId = String(call.id);
      const heading = document.createElement('div');
      heading.className = 'assistant-work-step-heading';
      const name = document.createElement('strong');
      name.textContent = toolDisplayName(call.name);
      const state = document.createElement('span');
      state.className = 'assistant-work-step-state';
      state.textContent = '실행 중';
      heading.append(name, state);
      step.appendChild(heading);
      if (detail) {
        const code = document.createElement('code');
        code.textContent = detail.slice(0, 240);
        step.appendChild(code);
      }
      const output = document.createElement('div');
      output.className = 'assistant-work-step-output';
      step.appendChild(output);
      details.open = true;
      card.workStepsNode.appendChild(step);
      card.currentWorkStep = step;
      card.workStepCount += 1;
      setAssistantWorkSummary(card, `작업 과정 · ${card.workStepCount}단계 · 진행 중`);
      setAssistantWorkStatus(card, `${toolDisplayName(call.name)} 중…`);
      timeline.scrollTop = timeline.scrollHeight;
      break;
    }

    case 'tool_approval_required': {
      const panel = document.createElement('section');
      panel.className = 'assistant-tool-approval';
      const heading = document.createElement('strong');
      heading.textContent = `승인 대기 · ${toolDisplayName(event.name)}`;
      const summary = document.createElement('pre');
      summary.textContent = JSON.stringify(event.args || {}, null, 2).slice(0, 4000);
      const approve = document.createElement('button');
      approve.type = 'button'; approve.textContent = '승인';
      const reject = document.createElement('button');
      reject.type = 'button'; reject.textContent = '거절';
      const decide = async decision => {
        approve.disabled = reject.disabled = true;
        try {
          const response = await fetch('/api/tool-approval', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ requestId: event.requestId, sessionId: event.sessionId, decision }) });
          if (!response.ok) throw new Error('승인 요청이 만료되었거나 세션이 변경되었습니다.');
          heading.textContent = decision === 'approve' ? '승인됨 · 실행을 계속합니다' : '거절됨 · 호출을 건너뜁니다';
        } catch (error) { heading.textContent = error.message; }
        approve.remove(); reject.remove();
      };
      approve.addEventListener('click', () => void decide('approve'));
      reject.addEventListener('click', () => void decide('reject'));
      panel.append(heading, summary, approve, reject);
      card.content.appendChild(panel);
      setAssistantWorkStatus(card, '도구 실행 전 사용자 승인을 기다리고 있습니다…');
      timeline.scrollTop = timeline.scrollHeight;
      break;
    }

    case 'tool_output': {
      const output = String(event.text || '').trim();
      if (!output) break;
      const step = card.currentWorkStep;
      const outputNode = step?.querySelector('.assistant-work-step-output');
      if (outputNode) {
        const block = document.createElement('pre');
        block.textContent = output.slice(-4000);
        outputNode.appendChild(block);
      }
      setAssistantWorkStatus(card, '작업 결과를 확인하고 있습니다…');
      timeline.scrollTop = timeline.scrollHeight;
      break;
    }

    case 'tool_end': {
      const detail = event.result || {};
      const result = detail.result || {};
      const call = detail.call || {};
      const failed = Boolean(result.error) || (Number.isInteger(result.exitCode) && result.exitCode !== 0);
      const step = call.id
        ? Array.from(card.workStepsNode?.querySelectorAll('[data-tool-call-id]') || []).find(node => node.dataset.toolCallId === String(call.id))
        : card.currentWorkStep;
      const state = step?.querySelector('.assistant-work-step-state');
      if (state) {
        state.textContent = failed ? `실패${result.exitCode === undefined || result.exitCode === null ? '' : ` · 종료 코드 ${result.exitCode}`}` : '완료';
        state.dataset.state = failed ? 'error' : 'complete';
      }
      if (failed) card.workOutcome = 'error';
      card.currentWorkStep = null;
      setAssistantWorkStatus(card, failed ? '단계 실패 · 다음 결과를 확인 중입니다' : '다음 작업 단계를 준비하고 있습니다…');
      timeline.scrollTop = timeline.scrollHeight;
      break;
    }
  }
}

window.toggleAssistantMore = function(btn) {
  const content = btn.closest('.bubble').querySelector('.assistant-content');
  if (content.style.maxHeight) {
    content.style.maxHeight = null;
    btn.innerHTML = 'Show more <span>⌄</span>';
  } else {
    content.style.maxHeight = 'none';
    btn.innerHTML = 'Show less <span>▴</span>';
  }
};

window.copyAssistantText = function(btn) {
  const text = btn.closest('.bubble').querySelector('.assistant-content').innerText;
  navigator.clipboard.writeText(text);
  btn.style.color = 'var(--accent-orange)';
  setTimeout(() => { btn.style.color = ''; }, 1200);
};

// ============================================================================
// Sessions & Navigation
// ============================================================================

function startNewSession() {
  currentSessionId = `session_${Date.now()}`;
  timeline.innerHTML = '';
  if (emptyState) {
    timeline.appendChild(emptyState);
    emptyState.style.display = 'flex';
  }
  titlebarThreadTitle.textContent = 'Only Chat · 채팅만으로 코딩 완결';
  composerInput.value = '';
  composerInput.focus();
  applyPendingUiMorphReloadWhenSafe();
}

let currentFilter = 'all'; // 'all', 'codex', 'antigravity', 'internal'
let cachedUnifiedData = null;
let sessionSearchQuery = '';
let sessionSearchResults = null;
let sessionSearchRequestId = 0;
let sessionSearchTimer = null;
let sessionSearchAbortController = null;
const sessionContextMenu = document.getElementById('sessionContextMenu');
let sessionContextTarget = null;

function setDropTargetFeedback(target, active) {
  target.classList.toggle('drop-target-active', active);
  target.setAttribute('aria-dragover', String(active));
}

function attachSessionDropTarget(target, destination) {
  if (!target || target.dataset.sessionDropReady === 'true') return;
  target.dataset.sessionDropReady = 'true';
  target.classList.add('session-drop-target');
  target.setAttribute('aria-label', destination.type === 'section'
    ? `${destination.section} 섹션에 내부 세션 놓기`
    : destination.type === 'pinned' ? 'Pinned에 내부 세션 놓기' : 'Recents에 내부 세션 놓기');
  target.setAttribute('aria-dropeffect', 'move');
  target.tabIndex = 0;
  target.addEventListener('dragover', event => {
    // dragover runs in DataTransfer's protected mode: only the type list is available.
    if (!hasInternalSessionDragType(event.dataTransfer)) return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
    setDropTargetFeedback(target, true);
  });
  target.addEventListener('dragleave', event => {
    if (!target.contains(event.relatedTarget)) setDropTargetFeedback(target, false);
  });
  target.addEventListener('drop', async event => {
    event.preventDefault();
    setDropTargetFeedback(target, false);
    const sessionId = event.dataTransfer?.getData('application/x-only-chat-session') || '';
    const session = cachedUnifiedData?.internal?.find(item => item.sessionId === sessionId && item.source === 'internal');
    if (!/^ses_[a-f0-9]{16}$/.test(sessionId) || !session || session.archived) return;
    const mapped = mapSessionDropDestination(destination);
    if (!mapped) return;
    const response = await fetch('/api/sessions/metadata', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId, action: mapped.action, payload: mapped.payload })
    });
    const status = document.getElementById('sessionDropStatus');
    if (!response.ok) {
      if (status) status.textContent = '세션을 해당 그룹으로 이동하지 못했습니다.';
      return;
    }
    if (status) status.textContent = `${session.title || '내부 세션'}을(를) ${target.getAttribute('aria-label')}에 이동했습니다.`;
    await loadSessions();
  });
}

attachSessionDropTarget(document.getElementById('pinnedSessionGroup'), { type: 'pinned' });
attachSessionDropTarget(document.querySelector('[data-drop-type="recents"]'), { type: 'recents' });

function hideSessionContextMenu() {
  if (sessionContextMenu) sessionContextMenu.hidden = true;
  sessionContextTarget = null;
}

function openSessionContextMenu(session, x, y, trigger) {
  if (!sessionContextMenu || session.source !== 'internal' || !/^ses_[a-f0-9]{16}$/.test(session.sessionId || session.id || '')) return;
  sessionContextTarget = { session, trigger };
  sessionContextMenu.replaceChildren();
  const addAction = (label, action, payload) => {
    const button = document.createElement('button');
    button.type = 'button'; button.setAttribute('role', 'menuitem'); button.textContent = label;
    button.addEventListener('click', async () => {
      if (action === 'delete' && !window.confirm('이 내부 세션을 영구 삭제할까요?')) return hideSessionContextMenu();
      if (action === 'rename') { const title = window.prompt('새 세션 이름', session.title || ''); if (title === null) return hideSessionContextMenu(); payload = { title }; }
      if (action === 'move') { const section = window.prompt('세션 섹션 이름 (최대 32자)', session.section === 'recents' ? '' : session.section); if (section === null) return hideSessionContextMenu(); payload = { section: section.trim() || 'recents' }; }
      const response = await fetch('/api/sessions/metadata', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sessionId: session.sessionId || session.id, action, payload }) });
      hideSessionContextMenu();
      if (response.ok) await loadSessions();
      else window.alert('세션을 변경하지 못했습니다.');
    });
    sessionContextMenu.appendChild(button);
  };
  addAction('이름 변경', 'rename', {});
  addAction(session.pinned ? '고정 해제' : '고정', 'pin', { pinned: !session.pinned });
  addAction('섹션 이동…', 'move', {});
  addAction(session.archived ? '보관 해제' : '보관', 'archive', { archived: !session.archived });
  addAction('삭제…', 'delete', { confirm: true });
  sessionContextMenu.hidden = false;
  const rect = trigger?.getBoundingClientRect();
  sessionContextMenu.style.left = `${Math.max(4, Math.min(x ?? rect?.right ?? 4, window.innerWidth - 205))}px`;
  sessionContextMenu.style.top = `${Math.max(4, Math.min(y ?? rect?.bottom ?? 4, window.innerHeight - 220))}px`;
  sessionContextMenu.querySelector('button')?.focus();
}
document.addEventListener('click', event => { if (!sessionContextMenu?.contains(event.target)) hideSessionContextMenu(); });
document.addEventListener('keydown', event => { if (event.key === 'Escape') hideSessionContextMenu(); });

async function loadSessions() {
  try {
    const res = await fetch('/api/sessions');
    const data = await res.json();
    cachedUnifiedData = data;
    renderFilteredSessions();
  } catch (err) {
    console.warn('Failed to load sessions:', err);
  }
}

function renderFilteredSessions() {
  if (!cachedUnifiedData) return;
  const unified = cachedUnifiedData.unified || { sections: [] };
  const internal = cachedUnifiedData.internal || [];

  let recentsList = document.getElementById('sessionList');
  if (!recentsList) return;

  const query = sessionTitleSearch?.value.trim() || '';
  if (query) {
    if (pinnedSessionGroup) pinnedSessionGroup.hidden = true;
    if (codexProjectGroup) codexProjectGroup.hidden = true;
    const normalizedQuery = query.toLocaleLowerCase();
    if (normalizedQuery !== sessionSearchQuery) {
      sessionSearchQuery = normalizedQuery;
      sessionSearchResults = null;
      const requestId = ++sessionSearchRequestId;
      clearTimeout(sessionSearchTimer);
      sessionSearchAbortController?.abort();
      sessionSearchAbortController = new AbortController();
      recentsList.textContent = '세션 검색 중…';
      sessionSearchTimer = setTimeout(async () => {
        try {
          const response = await fetch('/api/sessions/search', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query }),
            signal: sessionSearchAbortController.signal
          });
          if (!response.ok) throw new Error('세션 검색 요청이 실패했습니다.');
          const data = await response.json();
          if (requestId !== sessionSearchRequestId) return;
          sessionSearchResults = data.results || [];
          renderSessionSearchResults();
        } catch (_) {
          if (requestId === sessionSearchRequestId) recentsList.textContent = '세션 검색을 완료하지 못했습니다.';
        }
      }, 250);
      return;
    }
    if (sessionSearchResults === null) {
      recentsList.textContent = '세션 검색 중…';
      return;
    }
    renderSessionSearchResults();
    return;
  }

  sessionSearchRequestId++;
  clearTimeout(sessionSearchTimer);
  sessionSearchAbortController?.abort();
  sessionSearchAbortController = null;
  sessionSearchQuery = '';
  sessionSearchResults = null;
  const showCodexGroups = currentFilter === 'all' || currentFilter === 'codex';
  const internalGroups = groupInternalSessions(internal, currentFilter);
  const pinnedItems = showCodexGroups ? [...(unified.pinned || []), ...internalGroups.pinned] : internalGroups.pinned;
  if (pinnedSessionGroup) pinnedSessionGroup.hidden = false;
  if (codexProjectGroup) codexProjectGroup.hidden = !showCodexGroups || !(unified.projects || []).length;
  renderSessionItems(pinnedSessionList, pinnedItems);
  renderProjectGroups(projectList, showCodexGroups ? (unified.projects || []) : []);
  recentsList.innerHTML = '';

  const recentsSection = unified.sections?.find(s => s.id === 'recents');
  const activeInternal = internal.filter(session => !session.archived);
  let allItems = [...(recentsSection?.items || []), ...internalGroups.recents];

  // Apply Filter
  if (currentFilter === 'codex') {
    allItems = allItems.filter(s => s.source === 'codex');
  } else if (currentFilter === 'antigravity') {
    allItems = allItems.filter(s => s.source === 'antigravity');
  } else if (currentFilter === 'internal') {
    allItems = allItems.filter(s => s.source === 'internal' || !s.source);
  }

  if (allItems.length === 0) recentsList.textContent = '해당 필터에 세션이 없습니다.';
  else renderSessionItems(recentsList, allItems);
  const archived = currentFilter === 'all' || currentFilter === 'internal' ? internal.filter(session => session.archived) : [];
  const archiveGroup = document.getElementById('archivedSessionGroup');
  const archiveList = document.getElementById('archivedSessionList');
  if (archiveGroup && archiveList) { archiveGroup.hidden = archived.length === 0; renderSessionItems(archiveList, archived); }
  recentsList.parentElement.querySelectorAll('[data-internal-session-section]').forEach(group => group.remove());
  for (const { section, sessions } of internalGroups.customSections) {
    const group = document.createElement('div'); group.className = 'sidebar-nav-group';
    group.dataset.internalSessionSection = 'true';
    attachSessionDropTarget(group, { type: 'section', section });
    const heading = document.createElement('div'); heading.className = 'nav-group-title'; heading.textContent = section; group.appendChild(heading);
    const list = document.createElement('div'); list.className = 'session-list'; group.appendChild(list);
    renderSessionItems(list, sessions);
    recentsList.parentElement.appendChild(group);
  }
}

function renderSessionSearchResults() {
  const recentsList = document.getElementById('sessionList');
  if (!recentsList) return;
  let results = sessionSearchResults || [];
  if (currentFilter === 'codex' || currentFilter === 'antigravity') {
    results = results.filter(session => session.source === currentFilter);
  } else if (currentFilter === 'internal') {
    results = [];
  }
  if (results.length === 0) {
    recentsList.textContent = '검색 결과가 없습니다.';
    return;
  }
  renderSessionItems(recentsList, results, true);
}

function renderSessionItems(recentsList, sessions, withSnippets = false) {
  if (!recentsList) return;
  recentsList.innerHTML = '';
  for (const ses of sessions) {
    const item = document.createElement('div');
    const sessionId = ses.id || ses.sessionId;
    item.className = `nav-item ${sessionId === currentSessionId ? 'active' : ''}`;
    const internalDraggable = ses.source === 'internal' && !ses.archived && /^ses_[a-f0-9]{16}$/.test(sessionId || '');
    if (internalDraggable && !withSnippets) {
      item.draggable = true;
      item.addEventListener('dragstart', event => {
        if (!event.dataTransfer) return;
        event.dataTransfer.setData('application/x-only-chat-session', sessionId);
        event.dataTransfer.effectAllowed = 'move';
      });
      item.addEventListener('dragend', () => document.querySelectorAll('.session-drop-target.drop-target-active').forEach(target => setDropTargetFeedback(target, false)));
    }
    if (withSnippets) item.classList.add('session-search-result');
    const title = document.createElement('span');
    title.className = 'nav-item-text';
    title.title = ses.title || '대화 세션';
    title.textContent = ses.title || '대화 세션';
    item.appendChild(title);
    if (withSnippets && ses.snippet) {
      const snippet = document.createElement('span');
      snippet.className = 'session-search-snippet';
      snippet.textContent = ses.snippet;
      item.appendChild(snippet);
    }
    item.addEventListener('click', () => loadSession(sessionId, ses.title, ses.source));
    if (ses.source === 'internal') {
      item.addEventListener('contextmenu', event => { event.preventDefault(); openSessionContextMenu(ses, event.clientX, event.clientY, item); });
      const menuButton = document.createElement('button'); menuButton.type = 'button'; menuButton.className = 'session-menu-button'; menuButton.setAttribute('aria-label', `${ses.title || '세션'} 메뉴`); menuButton.setAttribute('aria-haspopup', 'menu'); menuButton.textContent = '⋯';
      menuButton.addEventListener('click', event => { event.stopPropagation(); openSessionContextMenu(ses, null, null, menuButton); });
      item.appendChild(menuButton);
    }
    recentsList.appendChild(item);
  }
}

function renderProjectGroups(container, projects) {
  if (!container) return;
  container.innerHTML = '';
  for (const project of projects) {
    const group = document.createElement('details');
    group.className = 'sidebar-project-group';
    const title = document.createElement('summary');
    title.className = 'nav-item nav-item-text';
    title.textContent = project.name || 'Project';
    group.appendChild(title);
    const items = document.createElement('div');
    items.className = 'session-list';
    group.appendChild(items);
    let rendered = false;
    group.addEventListener('toggle', () => {
      if (group.open && !rendered) {
        renderSessionItems(items, project.items || []);
        rendered = true;
      }
    });
    container.appendChild(group);
  }
}

async function loadSession(sessionId, title, source = null) {
  currentSessionId = sessionId;
  titlebarThreadTitle.textContent = title || 'Only Chat 세션';
  if (emptyState) emptyState.style.display = 'none';
  timeline.innerHTML = '';

  // Resume internal and external sessions through the same API, preserving source routing.
  if (source === 'internal' || sessionId.startsWith('ses_') || sessionId.startsWith('codex_') || sessionId.startsWith('agy_')) {
    try {
      const res = await fetch('/api/sessions/resume', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId })
      });
      const data = await res.json();
      if (data.ok && data.session && data.session.turns) {
        titlebarThreadTitle.textContent = data.session.source === 'internal'
          ? (data.session.title || title || 'Only Chat 세션')
          : `${data.session.title} (${data.session.source === 'codex' ? 'Codex' : 'Antigravity'} 재개됨)`;
        
        for (const t of data.session.turns) {
          if (t.role === 'user') {
            appendUserMessage(t.content);
          } else if (t.role === 'assistant') {
            const card = createAssistantContainer();
            const msg = document.createElement('div');
            msg.className = 'text-body';
            const answer = document.createElement('div');
            answer.className = 'assistant-answer';
            const renderMarkdown = window.OnlyChatPresentation?.renderMarkdown;
            if (typeof renderMarkdown === 'function') answer.innerHTML = renderMarkdown(t.content);
            else answer.textContent = t.content;
            msg.appendChild(answer);
            card.content.appendChild(msg);
            timeline.appendChild(card.row);
          }
        }
        timeline.scrollTop = timeline.scrollHeight;
      }
    } catch (err) {
      console.warn('Failed to resume session:', err);
    }
  }

  await loadSessions();
}

// ============================================================================
// Metamorphic Hub & Connectors & Browser & Vault
// ============================================================================

function initMetamorphicLiveStream() {
  try {
    const morphSource = new EventSource('/api/morph/stream');
    morphSource.onmessage = e => {
      try {
        const event = JSON.parse(e.data);
        if (event.type === 'morph_connected') {
          renderMorphSlots(event.status.slots);
        } else if (event.type === 'system_morph') {
          handleLiveMorphUpdate(event);
        }
      } catch (_) {}
    };
  } catch (err) {
    console.warn('Metamorphic stream deferred:', err);
  }
}

/**
 * 핫리로드 _ 신체 변형 시스템: 실시간 무중단 신체 부위 핫스왑 처리
 */
function handleLiveMorphUpdate(event) {
  const { organ, payload } = event;
  if (organ === 'ui' && typeof payload?.file === 'string' && /\.(?:html|js)$/i.test(payload.file)) {
    requestSafeUiMorphReload();
    return;
  }
  showMorphToast(`⚡️ 신체 변형 적용됨: [${organ}] (v${event.slot?.version || 'new'})`);

  if (organ === 'theme') {
    // 1. Hot-reload CSS stylesheet live without touching conversation or input!
    const links = document.querySelectorAll('link[rel="stylesheet"]');
    links.forEach(link => {
      const href = link.getAttribute('href').split('?')[0];
      link.setAttribute('href', `${href}?v=${Date.now()}`);
    });
    // If specific color payload is provided, apply custom property instantly
    if (payload && payload.accentOrange) {
      document.documentElement.style.setProperty('--accent-orange', payload.accentOrange);
    }
  } else if (organ === 'font') {
    // 2. Hot-swap font family live
    if (payload && payload.fontSans) {
      document.documentElement.style.setProperty('--font-sans', payload.fontSans);
    }
  } else if (organ === 'ui') {
    console.log('[MetamorphicHub] UI metadata refreshed.');
  }

  refreshMorphStatus();
}

function canReloadRendererNow({ inFlight, hasDraft, hasAttachments, hasConversation }) {
  return !inFlight && !hasDraft && !hasAttachments && !hasConversation;
}

function requestSafeUiMorphReload() {
  const attachmentInputs = ['attachmentPicker', 'folderPicker']
    .map(id => document.getElementById(id))
    .filter(Boolean);
  const safe = canReloadRendererNow({
    inFlight: isGenerating,
    hasDraft: Boolean(composerInput?.value.trim()),
    hasAttachments: attachmentInputs.some(input => input.files && input.files.length > 0),
    hasConversation: Boolean(timeline?.querySelector('.message-row'))
  });
  if (!safe) {
    pendingUiMorphReload = true;
    showMorphToast('UI 변경 감지됨 · 대화, 작성 내용, 첨부를 보존하려고 새 세션에서 적용합니다.');
    return;
  }
  clearTimeout(uiMorphReloadTimer);
  uiMorphReloadTimer = setTimeout(() => {
    uiMorphReloadTimer = null;
    if (!canReloadRendererNow({
      inFlight: isGenerating,
      hasDraft: Boolean(composerInput?.value.trim()),
      hasAttachments: attachmentInputs.some(input => input.files && input.files.length > 0),
      hasConversation: Boolean(timeline?.querySelector('.message-row'))
    })) {
      pendingUiMorphReload = true;
      showMorphToast('UI 변경 감지됨 · 현재 대화를 마치고 새 세션에서 적용합니다.');
      return;
    }
    pendingUiMorphReload = false;
    window.location.reload();
  }, 350);
}

function applyPendingUiMorphReloadWhenSafe() {
  if (pendingUiMorphReload) requestSafeUiMorphReload();
}

function showMorphToast(text) {
  let toast = document.getElementById('morphToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'morphToast';
    toast.style.cssText = `
      position: fixed;
      top: 54px;
      right: 20px;
      background: #18181b;
      color: #ffffff;
      border: 1px solid rgba(240, 106, 53, 0.4);
      box-shadow: 0 4px 16px rgba(0,0,0,0.2);
      padding: 8px 14px;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 500;
      z-index: 9999;
      display: flex;
      align-items: center;
      gap: 6px;
      animation: fadeIn 0.2s ease-out;
    `;
    document.body.appendChild(toast);
  }
  toast.textContent = text;
  toast.style.display = 'flex';
  clearTimeout(window._morphToastTimer);
  window._morphToastTimer = setTimeout(() => {
    if (toast) toast.style.display = 'none';
  }, 2400);
}

async function refreshMorphStatus() {
  try {
    const res = await fetch('/api/morph/status');
    const status = await res.json();
    renderMorphSlots(status.slots);
  } catch (_) {}
}

function renderMorphSlots(slots) {
  if (!slots || !morphSlotsList) return;
  morphSlotsList.innerHTML = '';
  for (const [key, slot] of Object.entries(slots)) {
    const organ = slot.organ || key;
    const changedAt = Number.isFinite(Number(slot.lastModified))
      ? new Date(Number(slot.lastModified)).toLocaleString()
      : '정보 없음';
    const card = document.createElement('div');
    card.className = 'tier-list-card';
    card.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <span style="font-weight:700; font-size:12px;">${slot.name} (${organ})</span>
        <span style="font-size:10px; background:rgba(0,0,0,0.06); padding:2px 6px; border-radius:4px;">v${slot.version}</span>
      </div>
      <div style="font-size:11px; color:var(--text-dim); margin-top:2px;">마지막 변경: ${changedAt}</div>
    `;
    morphSlotsList.appendChild(card);
  }
}

async function refreshConnectorsStatus() {
  try {
    const res = await fetch('/api/connectors/status');
    const status = await res.json();
    const googleBadge = document.getElementById('badgeGoogleStatus');
    const notionBadge = document.getElementById('badgeNotionStatus');

    if (status.google.connected) {
      googleBadge.textContent = '● 연결됨 · Drive/Gmail MCP';
      googleBadge.style.color = '#10b981';
    } else {
      googleBadge.textContent = '○ Google 연결 필요';
    }

    if (status.notion.connected) {
      notionBadge.textContent = '● 연결됨 (Active)';
      notionBadge.style.color = '#10b981';
    } else {
      notionBadge.textContent = '○ 미연동';
    }
  } catch (_) {}
}

async function handleGoogleLogin() {
  try {
    const res = await fetch('/api/connectors/google/auth-url');
    const data = await res.json();
    if (data.url) {
      const popup = window.open(data.url, '_blank', 'width=600,height=700');
      if (!popup) throw new Error('로그인 창이 차단됐습니다. 팝업을 허용한 뒤 다시 시도해 주세요.');
      const refreshTimer = setInterval(() => {
        if (popup.closed) {
          clearInterval(refreshTimer);
          void refreshConnectorsStatus();
        }
      }, 500);
    }
  } catch (err) {
    alert('구글 로그인 오류: ' + err.message);
  }
}

async function handleNotionConnect() {
  const token = document.getElementById('inputNotionToken').value.trim();
  if (!token) return alert('Notion 토큰을 입력해주세요.');
  try {
    const res = await fetch('/api/connectors/notion/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token })
    });
    const data = await res.json();
    if (data.ok) {
      alert('✓ Notion 연동 성공!');
      document.getElementById('inputNotionToken').value = '';
      await refreshConnectorsStatus();
    }
  } catch (err) {
    alert('Notion 오류: ' + err.message);
  }
}

async function refreshVaultList() {
  const container = document.getElementById('vaultList');
  if (!container) return;
  try {
    const res = await fetch('/api/vault/list');
    const items = await res.json();
    if (!items || items.length === 0) {
      container.innerHTML = `<div style="font-size:11px; color:var(--text-dim); padding:4px;">저장된 패스키가 없습니다.</div>`;
      return;
    }
    container.innerHTML = items.map(item => `
      <div style="background:#f4f4f5; border-radius:6px; padding:6px 10px; display:flex; justify-content:space-between; align-items:center;">
        <div>
          <div style="font-size:12px; font-weight:600; color:var(--text-main);">🔑 ${escapeHtml(item.service)}</div>
          <div style="font-size:10px; color:var(--text-dim);">${escapeHtml(item.username || '(계정 미지정)')} · ${item.allowAiUse ? 'AI 승인됨' : 'AI 차단됨'}</div>
        </div>
        <button style="border:none; background:transparent; color:var(--accent-red); cursor:pointer;" onclick="handleVaultDelete('${item.id}')">✕</button>
      </div>
    `).join('');
  } catch (_) {}
}

async function handleVaultSave() {
  const service = document.getElementById('inputVaultService').value.trim();
  const username = document.getElementById('inputVaultUsername').value.trim();
  const secret = document.getElementById('inputVaultSecret').value.trim();
  const allowAiUse = document.getElementById('checkVaultAllowAi').checked;

  if (!service || !secret) return alert('서비스명과 패스키를 입력해주세요.');

  try {
    const res = await fetch('/api/vault/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ service, username, secret, allowAiUse })
    });
    const result = await res.json();
    if (result.ok) {
      alert(`✓ [${service}] 패스키가 AES-GCM 보관함에 안전하게 저장되었습니다.`);
      document.getElementById('inputVaultService').value = '';
      document.getElementById('inputVaultUsername').value = '';
      document.getElementById('inputVaultSecret').value = '';
      await refreshVaultList();
    }
  } catch (err) {
    alert('보관함 오류: ' + err.message);
  }
}

window.handleVaultDelete = async function(id) {
  if (!confirm('이 패스키를 삭제하시겠습니까?')) return;
  try {
    await fetch('/api/vault/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    await refreshVaultList();
  } catch (_) {}
};

async function navBrowser(url) {
  const consoleEl = document.getElementById('browserAriaConsole');
  url = window.onlyChatResolveBrowserInput?.(url) || null;
  if (!url) {
    consoleEl.textContent = '[주소 오류] HTTP/HTTPS 주소를 확인해 주세요.';
    return;
  }
  document.getElementById('browserUrlInput').value = url;
  if (!(await threefControlEnabled())) { consoleEl.textContent = '[3F Browser 제어가 꺼져 있습니다.]'; return; }
  try {
    const response = await fetch('/api/browser/threef/open', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({url}) });
    const result = await response.json();
    consoleEl.textContent = response.ok ? '[3F Browser에서 열기 요청을 보냈습니다.]' : `[3F Browser 오류] ${result.error || result.stderr || '요청 실패'}`;
  } catch (error) { consoleEl.textContent = `[3F Browser 오류] ${error.message}`; }
}

async function threefControlEnabled() {
  return threefControlAllowed;
}
function setThreefControlUi(enabled) {
  const toggle = document.getElementById('threefControlEnabled');
  if (toggle) toggle.checked = enabled;
  for (const control of [
    document.getElementById('btnBrowserNav'), document.getElementById('btnBrowserThreef'),
    document.getElementById('btnBrowserAria'), document.getElementById('btnBrowserRead'),
    ...document.querySelectorAll('[data-browser-action]')
  ]) if (control) control.disabled = !enabled;
}
async function refreshThreefControlStatus() {
  try {
    const settingsResponse = await fetch('/api/browser/threef/settings', {cache:'no-store'});
    const settings = await settingsResponse.json();
    if (!settingsResponse.ok) throw new Error(settings.error || '3F Browser 설정을 읽지 못했습니다.');
    threefControlAllowed = settings.enabled === true;
    setThreefControlUi(threefControlAllowed);
    const statusElement = document.getElementById('threefControlStatus');
    if (!threefControlAllowed) {
      statusElement.textContent = '3F Browser 제어 꺼짐';
      const surface = document.getElementById('browserNativeSurface');
      if (surface) surface.textContent = '3F Browser 제어가 꺼져 있습니다. 켜면 Only Chat의 브라우저 작업이 독립 실행 중인 3F Browser 앱으로 전달됩니다.';
      return;
    }
    const response = await fetch('/api/browser/status', {cache:'no-store'});
    const status = await response.json();
    statusElement.textContent = status.statusText || '3F Browser 상태를 알 수 없습니다.';
    const surface = document.getElementById('browserNativeSurface');
    if (surface) surface.textContent = status.controlAvailable
      ? `독립 3F Browser 연결됨${status.title ? ` · ${status.title}` : ''}${status.activeUrl ? `\n${status.activeUrl}` : ''}`
      : `${status.statusText || '3F Browser 연결 상태를 알 수 없습니다.'}\n이동·읽기·페이지 조작은 연결이 확인된 뒤 사용할 수 있습니다.`;
  } catch (error) {
    threefControlAllowed = false;
    setThreefControlUi(false);
    document.getElementById('threefControlStatus').textContent = error.message || '3F Browser 상태를 확인할 수 없습니다.';
  }
}

async function handleBrowserOpenInThreef() {
  const consoleEl = document.getElementById('browserAriaConsole');
  const url = window.onlyChatResolveBrowserInput?.(document.getElementById('browserUrlInput').value) || null;
  if (!url) { consoleEl.textContent = '[주소 오류] HTTP/HTTPS 주소를 확인해 주세요.'; return; }
  await navBrowser(url);
}

async function handleBrowserAria() {
  const consoleEl = document.getElementById('browserAriaConsole');
  if (!(await threefControlEnabled())) { consoleEl.textContent = '[3F Browser 제어가 꺼져 있습니다.]'; return; }
  consoleEl.textContent = `[3F Browser 페이지 연결 확인 중...]`;
  try {
    const res = await fetch('/api/browser/aria', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    });
    const data = await res.json();
    consoleEl.textContent = `[3F Browser 페이지 접근성 정보]\n\n` + (data.ariaTree || data.error || '정보 없음');
  } catch (err) {
    consoleEl.textContent = `[오류]: ${err.message}`;
  }
}

async function handleBrowserRead() {
  const consoleEl = document.getElementById('browserAriaConsole');
  if (!(await threefControlEnabled())) { consoleEl.textContent = '[3F Browser 제어가 꺼져 있습니다.]'; return; }
  try {
    const res = await fetch('/api/browser/read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    });
    const data = await res.json();
    consoleEl.textContent = `[3F Browser 페이지 텍스트]\n\n` + (data.stdout || data.stderr || '텍스트 없음');
  } catch (err) {
    consoleEl.textContent = `[오류]: ${err.message}`;
  }
}

function sendBrowserPanelAction(action) {
  if (!threefControlAllowed) { document.getElementById('browserAriaConsole').textContent = '[3F Browser 제어가 꺼져 있습니다.]'; return; }
  fetch('/api/browser/history', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action })
  }).then(async response => {
    const result = await response.json();
    if (!response.ok || result.ok === false) throw new Error(result.stderr || result.error || '3F Browser 동작 실패');
    if (result.url) document.getElementById('browserUrlInput').value = result.url;
    document.getElementById('browserAriaConsole').textContent = `[3F Browser ${action}] ${result.stdout || result.url || '완료'}`;
  }).catch(error => { document.getElementById('browserAriaConsole').textContent = `[3F Browser 오류] ${error.message}`; });
}

// The native surface is transport-only; these callbacks are also available to its adapter.
window.onlyChatEmbeddedThreefCommand = async command => {
  if (!(await threefControlEnabled())) return { error: '3F Browser 제어가 꺼져 있습니다.' };
  const action = command?.action;
  const routes = { navigate: ['/api/browser/threef/open', 'POST', { url: command.url }], aria: ['/api/browser/aria', 'POST', {}], read: ['/api/browser/read', 'POST', {}], back: ['/api/browser/history', 'POST', { action }], forward: ['/api/browser/history', 'POST', { action }], reload: ['/api/browser/history', 'POST', { action }], status: ['/api/browser/status', 'GET'], act: ['/api/browser/act', 'POST', { action: command.value }] };
  const request = routes[action];
  if (!request) return { error: '지원하지 않는 3F Browser 명령입니다.' };
  try {
    const [url, method, body] = request;
    const response = await fetch(url, { method, cache:'no-store', ...(body ? { headers:{'Content-Type':'application/json'}, body:JSON.stringify(body) } : {}) });
    const result = await response.json();
    return response.ok ? result : { ...result, error: result.error || result.stderr || `3F Browser 요청 실패 (${response.status})` };
  } catch (error) { return { error: error.message || '3F Browser에 연결할 수 없습니다.' }; }
};

function syncNativeBrowserPanel() {
  const surface = document.getElementById('browserNativeSurface');
  if (!surface) return;
  const rect = surface.getBoundingClientRect();
  window.webkit?.messageHandlers?.browserPanel?.postMessage({
    action: 'layout',
    visible: drawerBrowser.classList.contains('open'),
    rect: { x: rect.left, y: rect.top, width: rect.width, height: rect.height }
  });
  btnToggleBrowser?.setAttribute('aria-expanded', String(drawerBrowser.classList.contains('open')));
  btnToggleBrowser?.setAttribute('aria-label', drawerBrowser.classList.contains('open') ? '3F Browser 닫기' : '3F Browser 열기');
  surface.setAttribute('aria-label', drawerBrowser.classList.contains('open')
    ? 'Only Chat 안에 표시된 3F Browser. 탐색과 페이지 읽기는 현재 화면과 같은 세션을 사용합니다.'
    : '3F Browser 패널');
}

function setBrowserPanelOpen(open) {
  drawerBrowser.classList.toggle('open', open);
  syncNativeBrowserPanel();
}

let embeddedThreefPollRunning = false;
async function pollEmbeddedThreefCommands() {
  if (embeddedThreefPollRunning || !window.webkit?.messageHandlers?.browserPanel || !threefControlAllowed) return;
  embeddedThreefPollRunning = true;
  try {
    const response = await fetch('/api/browser/panel/next', { cache: 'no-store' });
    if (response.status === 200) {
      const command = await response.json();
      if (!threefControlAllowed) return;
      setBrowserPanelOpen(true);
      window.setTimeout(() => window.webkit.messageHandlers.browserPanel.postMessage({ action: 'agent', command }), 80);
    }
  } catch (_) {
    // The native bridge starts after the local server and the panel can reopen later.
  } finally {
    embeddedThreefPollRunning = false;
    if (threefControlAllowed) window.setTimeout(pollEmbeddedThreefCommands, 300);
  }
}

window.onlyChatBrowserCommandComplete = async (id, result) => {
  try {
    await fetch('/api/browser/panel/complete', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, result })
    });
  } catch (_) {}
};

setThreefControlUi(false);
window.setTimeout(() => { void refreshThreefControlStatus(); }, 300);

window.onlyChatBrowserResult = ({ action, text, error }) => {
  document.getElementById('browserAriaConsole').textContent = error
    ? `[브라우저 오류] ${error}`
    : action === 'aria' ? `[3F Browser 접근성 정보]\n\n${text}` : `[3F Browser 페이지 텍스트]\n\n${text}`;
};

window.onlyChatBrowserNavigateResult = ({ url }) => {
  if (!url) return;
  document.getElementById('browserUrlInput').value = url;
  document.getElementById('browserAriaConsole').textContent = `[3F Browser 세션] ${url}`;
};

async function loadReaApps() {
  const container = document.getElementById('reaAppList');
  if (!container) return;
  try {
    const res = await fetch('/api/rea/apps');
    const apps = await res.json();
    container.innerHTML = apps.slice(0, 6).map(app => `
      <div style="background:#f4f4f5; padding:6px 10px; border-radius:6px; font-size:11px; display:flex; justify-content:space-between; align-items:center;">
        <span>${escapeHtml(app.name)}</span>
        <span style="color:var(--text-dim);">${app.framework}</span>
      </div>
    `).join('');
  } catch (_) {}
}

async function handleRegisterAccount() {
  const provider = document.getElementById('newAccProvider').value;
  const email = document.getElementById('newAccEmail').value.trim();
  const token = document.getElementById('newAccToken').value.trim();
  if (!email) return alert('이메일을 입력하세요.');
  try {
    await fetch('/api/accounts/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ provider, email, token })
    });
    alert('현재는 설치된 Codex CLI 계정만 지원합니다. 계정/토큰은 등록되지 않았습니다.');
    document.getElementById('newAccEmail').value = '';
    document.getElementById('newAccToken').value = '';
    await refreshPriorityStatus();
  } catch (err) {
    alert('계정 등록 실패: ' + err.message);
  }
}

function escapeHtml(text) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
  return String(text).replace(/[&<>"']/g, m => map[m]);
}

// ==========================================================================
// Full-Stage Settings View Helpers
// ==========================================================================
function isSettingsStageOpen() {
  const stage = document.getElementById('settingsStage');
  return stage && stage.style.display !== 'none';
}

function openSettingsStage(targetTab = 'general') {
  const chatStage = document.querySelector('.chat-stage');
  const settingsStage = document.getElementById('settingsStage');
  if (chatStage) chatStage.style.display = 'none';
  if (settingsStage) settingsStage.style.display = 'flex';

  // Titlebar indicator
  if (titlebarThreadTitle) {
    titlebarThreadTitle.setAttribute('data-prev', titlebarThreadTitle.innerText);
    titlebarThreadTitle.innerText = 'Only Chat · Settings';
  }

  // Switch to requested tab
  switchSettingsTab(targetTab);
  if (targetTab === 'general') void refreshWorkspaceOwnership();
  refreshStageVault();
}

async function refreshWorkspaceOwnership() {
  const liveStatus = document.getElementById('workspaceOwnershipLiveStatus');
  const leaseStatus = document.getElementById('workspaceLeaseStatus');
  const leaseDetail = document.getElementById('workspaceLeaseDetail');
  const gitStatus = document.getElementById('workspaceGitStatus');
  if (!leaseStatus || !gitStatus) return;
  if (liveStatus) liveStatus.textContent = '작업 상태를 확인하고 있습니다.';
  try {
    const response = await fetch('/api/ownership');
    if (!response.ok) throw new Error('status_unavailable');
    const presented = presentWorkspaceOwnership(await response.json());
    leaseStatus.textContent = presented.leaseText;
    leaseDetail.textContent = presented.leaseDetail;
    gitStatus.textContent = presented.gitText;
    if (liveStatus) liveStatus.textContent = `${presented.leaseText} ${presented.gitText}`;
  } catch (_) {
    leaseStatus.textContent = '작업 상태를 알 수 없습니다.';
    leaseDetail.textContent = '';
    gitStatus.textContent = 'Git 상태를 확인할 수 없습니다.';
    if (liveStatus) liveStatus.textContent = '작업 상태와 Git 상태를 확인할 수 없습니다.';
  }
}

function closeSettingsStage() {
  const chatStage = document.querySelector('.chat-stage');
  const settingsStage = document.getElementById('settingsStage');
  if (settingsStage) settingsStage.style.display = 'none';
  if (chatStage) chatStage.style.display = 'flex';

  if (titlebarThreadTitle) {
    const prev = titlebarThreadTitle.getAttribute('data-prev');
    if (prev) titlebarThreadTitle.innerText = prev;
    else titlebarThreadTitle.innerText = 'Only Chat · Just Chat. We Code.';
  }

  if (composerInput) composerInput.focus();
}

function toggleSettingsStage() {
  if (isSettingsStageOpen()) {
    closeSettingsStage();
  } else {
    openSettingsStage();
  }
}

function switchSettingsTab(tabId) {
  // Hide all panels
  document.querySelectorAll('.settings-panel-view').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.settings-nav-item').forEach(i => {
    if (i.getAttribute('data-tab') === tabId) {
      i.classList.add('active');
    } else {
      i.classList.remove('active');
    }
  });

  if (tabId === 'general') {
    const p = document.getElementById('panelTabGeneral');
    if (p) p.classList.add('active');
  } else if (tabId === 'models') {
    const p = document.getElementById('panelTabModels');
    if (p) p.classList.add('active');
  } else if (tabId === 'providers') {
    const p = document.getElementById('panelTabProviders');
    if (p) p.classList.add('active');
  } else if (tabId === 'windows-sync') {
    const p = document.getElementById('panelTabWindowsSync');
    if (p) p.classList.add('active');
    void refreshWindowsInbox();
  } else if (tabId === 'passwords') {
    const p = document.getElementById('panelTabPasswords');
    if (p) p.classList.add('active');
    refreshStageVault();
  } else if (tabId === 'plugins') {
    const p = document.getElementById('panelTabPlugins');
    if (p) p.classList.add('active');
  } else if (tabId === 'security') {
    const p = document.getElementById('panelTabSecurity');
    if (p) p.classList.add('active');
  } else if (tabId === 'appearance') {
    const p = document.getElementById('panelTabAppearance');
    if (p) p.classList.add('active');
    const toggle = document.getElementById('fantasyWarriorModeToggle');
    if (toggle) toggle.checked = fantasyWarriorMode;
  } else {
    const p = document.getElementById('panelTabGeneric');
    if (p) {
      p.classList.add('active');
      const title = document.getElementById('genericPanelTitle');
      if (title) title.innerText = tabId.charAt(0).toUpperCase() + tabId.slice(1);
    }
  }
}

async function refreshWindowsInbox() {
  try {
    const response = await fetch('/api/evolution/inbox', { cache: 'no-store' });
    const status = await response.json();
    renderWindowsInbox(status);
  } catch (error) {
    const target = document.getElementById('windowsEvolutionStatus');
    if (target) target.textContent = `수신함 조회 실패: ${error.message}`;
  }
}

function renderWindowsInbox(status) {
  if (!status) return;
  const pathInput = document.getElementById('windowsEvolutionPath');
  const statusNode = document.getElementById('windowsEvolutionStatus');
  const list = document.getElementById('windowsEvolutionPending');
  const badge = document.getElementById('windowsChangesBadge');
  const pending = Array.isArray(status.pending) ? status.pending : [];
  if (pathInput && status.relayFolder && document.activeElement !== pathInput) pathInput.value = status.relayFolder;
  if (statusNode) statusNode.textContent = status.enabled
    ? `연결됨 · ${status.deviceId} · 대기 ${pending.length}건 · Drive 클라우드 수신은 미확인${status.error ? ` · 오류: ${status.error}` : ''}`
    : status.configured ? '연결 해제됨 · 공유 폴더 경로는 저장됨' : '미연결 · 공유 폴더를 한 번 선택해 주세요';
  if (badge) { badge.hidden = pending.length === 0; badge.textContent = String(pending.length); }
  if (!list) return;
  list.replaceChildren();
  if (!pending.length) {
    const empty = document.createElement('div'); empty.style.cssText = 'color:var(--text-dim);font-size:13px;';
    empty.textContent = status.enabled ? '반영 대기 중인 새 Windows 변경이 없습니다.' : '연결 후 새 변경 사항이 여기에 기록됩니다.';
    list.appendChild(empty); return;
  }
  for (const item of pending) {
    const card = document.createElement('article'); card.style.cssText = 'border:1px solid var(--border-color);border-radius:10px;padding:12px;margin-bottom:8px;';
    const title = document.createElement('strong'); title.textContent = item.summary || item.task || item.packetId;
    const state = document.createElement('div'); state.style.cssText = 'color:var(--text-dim);font-size:12px;margin-top:5px;'; state.textContent = `상태: ${item.state || 'pending'} · Windows 장치: ${item.authorDeviceId || '확인 불가'}`;
    const files = document.createElement('div'); files.style.cssText = 'color:var(--text-dim);font-size:12px;margin-top:5px;';
    files.textContent = (item.files || []).map(file => `${file.path} (${file.newHash?.slice(0, 12) || '해시 없음'})`).join(' · ') || item.error || '파일 메타데이터 없음';
    card.append(title, state, files); list.appendChild(card);
  }
}

async function refreshStageVault() {
  const stageList = document.getElementById('stageVaultList');
  if (!stageList) return;
  try {
    const res = await fetch('/api/vault/list');
    const data = await res.json();
    if (!data.credentials || data.credentials.length === 0) {
      stageList.innerHTML = '<div style="font-size: 13px; color: #9ca3af; padding: 12px 0;">등록된 자격증명이 없습니다.</div>';
      return;
    }
    stageList.innerHTML = data.credentials.map(c => `
      <div style="display: flex; align-items: center; justify-content: space-between; padding: 10px 14px; border: 1px solid #e5e7eb; border-radius: 8px; margin-bottom: 6px;">
        <div>
          <span style="font-weight: 600; font-size: 13px; color: #111827;">${c.service}</span>
          <span style="font-size: 12px; color: #6b7280; margin-left: 8px;">${c.username || 'No user'}</span>
        </div>
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 11px; color: #10b981; background: rgba(16,185,129,0.1); padding: 2px 6px; border-radius: 4px;">AI 승인됨</span>
          <button class="btn-change-outline" style="padding: 2px 8px; font-size: 11px;" onclick="deleteVaultItem('${c.service}')">삭제</button>
        </div>
      </div>
    `).join('');
  } catch (err) {
    stageList.innerHTML = `<div style="color: #ef4444; font-size: 12px;">보관함 조회 오류: ${err.message}</div>`;
  }
}

async function handleStageVaultSave() {
  const service = document.getElementById('stageVaultService').value.trim();
  const username = document.getElementById('stageVaultUsername').value.trim();
  const secret = document.getElementById('stageVaultSecret').value.trim();
  const allowAi = document.getElementById('stageVaultAllowAi').checked;

  if (!service || !secret) {
    alert('서비스 이름과 패스키/비밀번호를 입력하세요.');
    return;
  }

  try {
    const res = await fetch('/api/vault/store', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ service, username, secret, allowAi })
    });
    const d = await res.json();
    if (d.success) {
      alert(`[보관함 저장 완료] ${service} 패스키가 안전하게 암호화 보관되었습니다.`);
      document.getElementById('stageVaultService').value = '';
      document.getElementById('stageVaultUsername').value = '';
      document.getElementById('stageVaultSecret').value = '';
      refreshStageVault();
    } else {
      alert('저장 실패: ' + (d.error || '알 수 없는 오류'));
    }
  } catch (err) {
    alert('요청 오류: ' + err.message);
  }
}

// ==========================================================================
// Aside Models & M-Oasis 1, 2, 3 Tier Priority Selection Logic
// ==========================================================================
function toggleKebabMenu(event, providerId) {
  event.stopPropagation();
  // Close all other kebabs
  document.querySelectorAll('.kebab-popover').forEach(p => {
    if (p.id !== `kebab-${providerId}`) p.classList.remove('open');
  });
  const popover = document.getElementById(`kebab-${providerId}`);
  if (popover) {
    popover.classList.toggle('open');
  }
}

// Close kebabs on click outside
document.addEventListener('click', e => {
  if (!e.target.closest('.kebab-menu-wrapper')) {
    document.querySelectorAll('.kebab-popover').forEach(p => p.classList.remove('open'));
  }
});

async function setAsRank(tierOrProviderId, rank) {
  const providerProfile = priorityStatus?.tiers?.find(tier => tier.id === tierOrProviderId);
  if (!providerProfile || !Number.isInteger(rank) || rank < 1 || rank > 3) return;
  // Close kebab
  document.querySelectorAll('.kebab-popover').forEach(p => p.classList.remove('open'));
  
  try {
    const res = await fetch('/api/priority/set-rank', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tierId: tierOrProviderId, rank })
    });
    const d = await res.json();
    if (d.ok) {
      alert(`[M-Oasis] ${tierOrProviderId} 모델이 ${rank}순위로 성공적으로 지정되었습니다.`);
      refreshPriorityStatus();
      loadStagePriorityTiers();
    } else {
      alert('순위 지정 실패: 등록되지 않은 체인 ID입니다. "+ Connect"로 먼저 추가하세요.');
    }
  } catch (err) {
    alert('요청 오류: ' + err.message);
  }
}

function reauthProvider(providerId) {
  document.querySelectorAll('.kebab-popover').forEach(p => p.classList.remove('open'));
  alert('Codex CLI 계정은 Only Chat이 보관하거나 다시 인증하지 않습니다. 설치된 Codex CLI에서 계정 상태를 관리하세요.');
}

function disconnectProvider(providerId) {
  document.querySelectorAll('.kebab-popover').forEach(p => p.classList.remove('open'));
  alert('Only Chat은 Codex CLI 계정을 연결 해제하거나 로컬 자격 증명을 변경하지 않습니다.');
}

function openConnectModal(preselectProvider = 'google') {
  const modal = document.getElementById('connectModal');
  if (modal) {
    modal.style.display = 'flex';
    if (preselectProvider) {
      document.getElementById('modalProviderSelect').value = preselectProvider;
    }
    document.getElementById('modalAccountName').focus();
  }
}

function closeConnectModal() {
  const modal = document.getElementById('connectModal');
  if (modal) modal.style.display = 'none';
}

async function handleConnectSubmit() {
  const provider = document.getElementById('modalProviderSelect').value;
  const email = document.getElementById('modalAccountName').value.trim();
  const apiKey = document.getElementById('modalApiKey').value.trim();
  const rank = parseInt(document.getElementById('modalPriorityRank').value, 10);

  if (!email && !apiKey && provider !== 'ollama') {
    alert('계정 이름 또는 API Key를 입력하세요.');
    return;
  }

  const id = `${provider}-${Date.now()}`;
  const name = `${provider.toUpperCase()} (${email || 'Default'})`;

  try {
    const res = await fetch('/api/priority/connect', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id,
        name,
        provider,
        model: provider === 'ollama' ? 'qwen2.5:7b' : 'auto',
        email,
        apiKey
      })
    });
    const d = await res.json();
    if (d.ok) {
      if (rank > 0) {
        await fetch('/api/priority/set-rank', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ tierId: id, rank })
        });
      }
      alert(`[연결 완료] ${name} 공급자가 추가되었습니다!`);
      closeConnectModal();
      refreshPriorityStatus();
      loadStagePriorityTiers();
    } else {
      alert('연결 실패');
    }
  } catch (err) {
    alert('연결 오류: ' + err.message);
  }
}

// Hook connect submit
const btnSubmitConnectModal = document.getElementById('btnSubmitConnectModal');
if (btnSubmitConnectModal) {
  btnSubmitConnectModal.addEventListener('click', handleConnectSubmit);
}

// Load Priority Tiers into Settings > Models Stage
async function loadStagePriorityTiers() {
  const container = document.getElementById('stagePriorityTiersGrid');
  if (!container) return;

  try {
    const res = await fetch('/api/status');
    const data = await res.json();
    const tiers = data.tiers || [];
    if (data.providers?.length) {
      const connected = data.providers.find(item => item.connected);
      const popupUsageSource = document.getElementById('popupUsageSource');
      const popupWeeklyLimit = document.getElementById('popupWeeklyLimit');
      const popupCredits = document.getElementById('popupCredits');
      if (popupUsageSource) popupUsageSource.textContent = 'Codex CLI';
      if (popupWeeklyLimit) popupWeeklyLimit.textContent = connected ? 'Connected' : data.providers[0].available ? 'Sign-in required' : 'Unavailable';
      if (popupCredits) popupCredits.textContent = 'Usage not reported';
    }
    const activeTierId = data.activeTier?.id;

    container.innerHTML = tiers.map((tier, idx) => {
      const isActive = tier.id === activeTierId;
      const rankNum = tier.tier || (idx + 1);
      const isCodex = String(tier.provider || '').toLowerCase().includes('codex');
      const tierIdentity = /secondary/i.test(`${tier.id} ${tier.name}`) ? '보조 계정' : /primary/i.test(`${tier.id} ${tier.name}`) ? '주 계정' : '계정';
      const accountId = tier.account || tier.id || 'ID 정보 없음';
      const readiness = tier.providerReady;
      return `
        <div class="priority-rank-card rank-tier-${rankNum} ${isActive ? 'active-tier' : ''} ${isCodex ? 'codex-account' : 'google-account'}">
          <div class="priority-rank-badge">
            <span>${rankNum}순위</span>
            ${isActive ? `<span style="font-size: 11px; font-weight: 700; background: #f06a35; color: #fff; padding: 3px 8px; border-radius: 6px;">${data.enabled === false ? '수동 고정 계정' : '현재 자동 라우팅 계정'}</span>` : ''}
          </div>
          <div class="priority-rank-name">${rankNum === 2 ? '2순위 · Codex 보조 계정' : rankNum === 3 ? '3순위 · Codex 주 계정' : `${rankNum}순위 계정 · ${isCodex ? `OpenAI Codex ${tierIdentity}` : escapeHtml(tier.name || tier.provider || '계정')}`}</div>
          <div class="priority-rank-model"><strong>${isActive ? '현재 선택/라우팅 모델' : '폴백 모델'}</strong><span>${escapeHtml(displayPriorityModel(tier.model))}</span></div>
          <div class="priority-rank-account"><strong>${isCodex ? `이 순위의 Codex 로그인 계정 (${tierIdentity})` : '이 순위의 로그인 계정'}</strong><span>${escapeHtml(tier.email || '이메일 정보 없음')}</span></div>
          <div class="priority-rank-account-id">계정 식별자 · ${escapeHtml(accountId)}</div>
          ${isCodex ? `<div class="priority-rank-ready ${readiness?.connected ? '' : 'not-ready'}">${escapeHtml(readiness?.connected ? 'Codex 계정 확인됨 · 요청 가능' : readiness?.message || 'Codex 로그인 상태 확인 불가')}</div>` : '<div class="priority-rank-ready">실행 경로 연결됨</div>'}
          <div class="priority-rank-health">${escapeHtml(tierQuotaLabel(tier))}</div>
          <div class="priority-rank-actions">
            <button class="btn-rank-action" onclick="setAsRank('${tier.id}', 1)" title="이 계정을 1순위로 설정">1순위</button>
            <button class="btn-rank-action" onclick="setAsRank('${tier.id}', 2)" title="이 계정을 2순위로 설정">2순위</button>
            <button class="btn-rank-action" onclick="setAsRank('${tier.id}', 3)" title="이 계정을 3순위로 설정">3순위</button>
            <button class="btn-rank-action" onclick="switchTier('${tier.id}')" ${isActive && data.enabled === false ? 'disabled' : ''} title="자동 우선순위를 끄고 이 계정을 수동 선택">${isActive && data.enabled === false ? '수동 선택됨' : '수동 선택'}</button>
          </div>
        </div>
      `;
    }).join('');
  } catch (err) {
    container.innerHTML = `<div style="color: #ef4444; font-size: 12px;">우선순위 체인 로드 오류: ${err.message}</div>`;
  }
}

// Ensure loadStagePriorityTiers runs on page load and settings open
window.addEventListener('load', () => {
  loadStagePriorityTiers();
});

// Patch openSettingsStage to always refresh stage priority tiers
const origOpenSettingsStage = openSettingsStage;
openSettingsStage = function(targetTab = 'models') {
  origOpenSettingsStage(targetTab);
  loadStagePriorityTiers();
};
