'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { formatHistory } = require('./AntigravityCliAdapter.js');
const { parseReasoningEffort } = require('../core/ReasoningEffort.js');

function tokenEmail(token) {
  if (typeof token !== 'string') return '';
  const parts = token.split('.');
  if (parts.length < 2) return '';
  try {
    const claims = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
    return String(claims.email || claims['https://api.openai.com/auth']?.email || '').trim().toLowerCase();
  } catch (_) {
    return '';
  }
}

function profileEmail(profileHome) {
  try {
    const auth = JSON.parse(fs.readFileSync(path.join(profileHome, 'auth.json'), 'utf8'));
    const tokens = auth.tokens || auth;
    return [tokenEmail(tokens.id_token), tokenEmail(tokens.access_token)].find(Boolean) || '';
  } catch (_) {
    return '';
  }
}

function failureMessage(text, tier, exitCode) {
  if (/model_not_found|model is not supported/i.test(text)) {
    return `Codex 계정 ${tier.email}에서 ${tier.model} 모델을 사용할 수 없습니다.`;
  }
  if (/\b429\b|rate.?limit|quota|resource.?exhausted/i.test(text)) {
    return `Codex 계정 ${tier.email}의 사용 한도에 도달했습니다.`;
  }
  if (/unauthorized|not logged in|authentication required/i.test(text)) {
    return `Codex 계정 ${tier.email} 로그인이 필요합니다.`;
  }
  return `Codex ${tier.model || '요청'}이 실패했습니다 (종료 코드 ${exitCode}).`;
}

class CodexCliAdapter {
  constructor(options = {}) {
    this.dataDir = path.resolve(options.dataDir || path.join(os.homedir(), '.my-codex'));
    this.command = options.command || path.join(this.dataDir, 'runtime/codex-cli/node_modules/.bin/codex');
    this.defaultCodexHome = path.resolve(options.defaultCodexHome || process.env.CODEX_HOME || path.join(os.homedir(), '.codex'));
    this.profilesDir = path.join(this.dataDir, 'codex-profiles');
    this.projectRoot = path.resolve(options.projectRoot || path.join(__dirname, '../..'));
    this.googleTokenFile = options.googleTokenFile || null;
    this.spawn = options.spawn || spawn;
    this.timeoutMs = options.timeoutMs || 120_000;
  }

  _accountProfile(tier) {
    const email = String(tier?.email || '').trim().toLowerCase();
    if (!email) return null;
    const id = String(tier?.id || '');
    const candidates = [];
    if (/^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/.test(id)) candidates.push(path.join(this.profilesDir, id));
    candidates.push(this.defaultCodexHome);
    const seen = new Set();
    for (const home of candidates) {
      if (seen.has(home)) continue;
      seen.add(home);
      if (profileEmail(home) === email) return home;
    }
    return null;
  }

  getReadiness(tier) {
    const hasCli = fs.existsSync(this.command);
    const email = String(tier?.email || '').trim().toLowerCase();
    const profile = hasCli ? this._accountProfile(tier) : null;
    return {
      available: hasCli,
      connected: Boolean(profile),
      email,
      message: !hasCli ? 'Only Chat 전용 Codex CLI가 없습니다.'
        : profile ? 'Codex 로그인 계정과 등록 이메일이 일치합니다.'
          : `별도 Codex 로그인 필요 · ${email || '계정 이메일 미등록'}`
    };
  }

  async call(tier, history, hooks = {}, context = {}) {
    const profile = this._accountProfile(tier);
    if (!profile) throw new Error(this.getReadiness(tier).message);
    const prompt = formatHistory(history);
    if (!prompt.trim()) throw new Error('Codex에 보낼 대화 내용이 없습니다.');
    const effort = parseReasoningEffort(context.reasoningEffort);
    if (!effort) throw new Error('지원하지 않는 추론 강도입니다.');
    if (!/^[a-z0-9][a-z0-9._-]*$/i.test(String(tier.model || ''))) throw new Error('Codex 모델 ID가 올바르지 않습니다.');

    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'onlychat-codex-'));
    const outputFile = path.join(tempDir, 'answer.txt');
    try {
      const args = [
        'exec', '--ignore-user-config', '--model', tier.model,
        '--sandbox', 'workspace-write', '--ephemeral', '--json', '--skip-git-repo-check',
        '--cd', context.workspaceDir || process.cwd(),
        '--output-last-message', outputFile,
        '-c', 'mcp_servers.onlychat_google.enabled=true',
        '-c', `mcp_servers.onlychat_google.command=${JSON.stringify(process.execPath)}`,
        '-c', `mcp_servers.onlychat_google.args=${JSON.stringify([path.join(this.projectRoot, 'src/connectors/GoogleWorkspaceMcpServer.js')])}`,
        '-c', 'approval_policy="on-request"',
        '-c', `model_reasoning_effort="${effort}"`, '-'
      ];
      const response = await this._run(args, prompt, profile, context.workspaceDir || process.cwd(), tier, hooks);
      if (!response.trim()) throw new Error(`Codex 계정 ${tier.email}에서 빈 응답을 받았습니다.`);
      hooks.onMessageDelta?.(response);
      return { content: response, toolCalls: [] };
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  }

  _run(args, prompt, profile, cwd, tier, hooks) {
    return new Promise((resolve, reject) => {
      let child;
      try {
        child = this.spawn(this.command, args, {
          cwd,
          env: { ...process.env, CODEX_HOME: profile, ONLY_CHAT_DATA_DIR: this.dataDir, ONLY_CHAT_GOOGLE_TOKEN_FILE: this.googleTokenFile || '' },
          stdio: ['pipe', 'pipe', 'pipe']
        });
      } catch (_) {
        reject(new Error('Only Chat 전용 Codex CLI를 시작할 수 없습니다.'));
        return;
      }
      let stdoutBuffer = '';
      let stdoutTail = '';
      let stderr = '';
      const activeTools = new Map();
      let settled = false;
      const finish = (error, value) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (error) {
          for (const call of activeTools.values()) hooks.onToolEnd?.({ call, result: { error: error.message } });
          activeTools.clear();
          reject(error);
        } else resolve(value);
      };
      const timer = setTimeout(() => {
        child.kill('SIGTERM');
        finish(new Error(`Codex 계정 ${tier.email} 응답 시간이 초과됐습니다.`));
      }, this.timeoutMs);
      child.stdout.setEncoding('utf8');
      child.stderr.setEncoding('utf8');
      child.stdout.on('data', chunk => {
        stdoutTail = (stdoutTail + chunk).slice(-12_000);
        stdoutBuffer += chunk;
        if (stdoutBuffer.length > 2 * 1024 * 1024) {
          child.kill('SIGTERM');
          finish(new Error('Codex 응답 크기가 제한을 넘었습니다.'));
          return;
        }
        let newline;
        while ((newline = stdoutBuffer.indexOf('\n')) !== -1) {
          const line = stdoutBuffer.slice(0, newline).trim();
          stdoutBuffer = stdoutBuffer.slice(newline + 1);
          if (line) this._handleEventLine(line, hooks, activeTools);
        }
      });
      child.stderr.on('data', chunk => { stderr = (stderr + chunk).slice(-12_000); });
      child.on('error', () => finish(new Error('Only Chat 전용 Codex CLI를 실행할 수 없습니다.')));
      child.on('close', code => {
        if (settled) return;
        if (stdoutBuffer.trim()) this._handleEventLine(stdoutBuffer.trim(), hooks, activeTools);
        if (code !== 0) {
          finish(new Error(failureMessage(`${stdoutTail}\n${stderr}`, tier, code)));
          return;
        }
        try {
          const outputPath = args[args.indexOf('--output-last-message') + 1];
          const response = fs.readFileSync(outputPath, 'utf8').trim();
          finish(null, response);
        } catch (_) {
          finish(new Error('Codex 응답을 읽을 수 없습니다.'));
        }
      });
      child.stdin.end([
        'Only Chat의 GPT-6 Luna 코딩 에이전트입니다. 사용자의 요청을 이 작업공간에서 실제로 수행하고, 필요한 경우 Codex 도구로 코드를 읽고 수정하거나 명령을 실행하세요.',
        '작업공간 밖의 파일·서비스·계정에는 접근하지 마세요. 전체 권한 우회 옵션을 사용하지 말고, 빌드·설치·다운로드는 프로젝트 지침의 안전 가드를 따르세요.',
        '파일이나 코드를 바꿔 달라는 요청에서 대상 경로가 분명하지 않으면 먼저 경로를 물어보세요. 실제 도구 실행의 성공 결과가 확인된 경우에만 변경을 완료했다고 말하고, 확인되지 않았으면 완료 여부를 모른다고 설명하세요.',
        '답변은 사용자가 바로 이해할 수 있는 쉬운 한국어로 간단히 쓰고, 실제 작업 시간은 Only Chat이 표시하므로 답변에서 시간을 추측하지 마세요.',
        '',
        prompt
      ].join('\n'));
    });
  }

  _handleEventLine(line, hooks, activeTools) {
    let event;
    try { event = JSON.parse(line); } catch (_) { return; }
    const item = event.item;
    if (!item || !['item.started', 'item.completed'].includes(event.type)) return;

    if (item.type === 'command_execution') {
      const id = String(item.id || item.command || `command-${activeTools.size}`);
      let call = activeTools.get(id);
      if (event.type === 'item.started') {
        if (call) return;
        call = { id, name: 'exec_command', args: { command: item.command || '' } };
        activeTools.set(id, call);
        hooks.onToolStart?.(call);
        return;
      }
      call ||= { id, name: 'exec_command', args: { command: item.command || '' } };
      const stdout = typeof item.stdout === 'string' ? item.stdout : '';
      const stderr = typeof item.stderr === 'string' ? item.stderr : '';
      const output = [stdout, stderr].filter(Boolean).join('\n');
      if (output) hooks.onToolOutput?.({ type: stderr ? 'stderr' : 'stdout', text: output.slice(-8000) });
      hooks.onToolEnd?.({ call, result: { exitCode: Number.isInteger(item.exit_code) ? item.exit_code : null, stdout, stderr } });
      activeTools.delete(id);
      return;
    }

    if (item.type === 'mcp_tool_call') {
      const id = String(item.id || `${item.server || 'mcp'}:${item.tool || 'tool'}`);
      let call = activeTools.get(id);
      if (event.type === 'item.started') {
        if (call) return;
        call = { id, name: `MCP · ${item.server || '도구'}/${item.tool || '호출'}`, args: {} };
        activeTools.set(id, call);
        hooks.onToolStart?.(call);
        return;
      }
      call ||= { id, name: `MCP · ${item.server || '도구'}/${item.tool || '호출'}`, args: {} };
      hooks.onToolEnd?.({ call, result: { completed: true } });
      activeTools.delete(id);
      return;
    }

    if (item.type === 'file_change' && event.type === 'item.completed') {
      for (const change of Array.isArray(item.changes) ? item.changes : []) {
        const filePath = String(change?.path || '');
        if (!filePath) continue;
        const call = { id: `${item.id || 'file'}:${filePath}`, name: 'file_change', args: { path: filePath, change: change.kind?.type || 'updated' } };
        hooks.onToolStart?.(call);
        hooks.onToolEnd?.({ call, result: { path: filePath, change: change.kind?.type || 'updated' } });
      }
    }
  }
}

module.exports = { CodexCliAdapter, profileEmail };
